
/* -------------------------------------------------------*/
/* The following code is generated automagically with     */
/* generate_auto.py. Yes, it is fairly ugly ;-)           */
/* -------------------------------------------------------*/

/* Class dir used: ../CLASS_LISTS_D6/ */

/* CLASS_H-NM-FFMM31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NS-FFSF11-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-SMLS00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NS-FFSF21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSLM33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFMM31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSS21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSMF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSS21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSMM33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFSF22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSS11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMS32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMF32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-PM-FFMF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMS31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-SMLM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PS-SSLF32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMS31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSS22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FMLM33-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-SMLM21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PF-FFSS32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMS31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMS32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMF32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-MMLM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFSF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFLM31-D : protocol_G-E--_107_B42_F1_PI_SE_Q4_CS_SP_PS_S0Y.csv 2    */
/* CLASS_G-NF-FFMF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SS-FFSF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFMS21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-NS-FFSF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFLM31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NS-FFSF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFMS22-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFLM32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFMS21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFLM32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFMS22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFMM32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-SMLM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PM-FFSS21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFSS21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFLF32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NS-FFSF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-SMLM22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFMM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-NF-FFSF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLS33-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFSS32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSS21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSS00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PF-FFSM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-PM-FFSF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-PM-FFSF22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFMM32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSS21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLS33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-FSLM21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFMM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-PM-FFSF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-FSLM21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-FSLM22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PM-FFSF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-PM-FFSF21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFMF32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-FSLM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFMM21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-FSLM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMF31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PS-FFSF31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSMS31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFMF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFSF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SS-FFSF32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMF32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMF32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SS-FFSF32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FSMM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PS-FSLF32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-SSLF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PS-FFSF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMF31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PS-FFSF32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFSF21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-MMLM32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLM33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMM11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FFMS22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSLS00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFMM33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMF22-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSMF31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FFMS31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-MMLM11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFSM33-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-SMLM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLM33-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSMS11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-SMLS11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PM-FFSF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMM22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMS32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMS32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFMM33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PS-FFMF32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSMM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PM-FFLM31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PM-FFSF22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PM-FFLM31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-SMLF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NS-FFSF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMS31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FFMM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FMLM32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMS33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFLS32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FMLM32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFMM11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFSF31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NS-FFSF11-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMS31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-SSLM33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLM11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FMLF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PM-FFSS21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-SMLF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PM-FFMF32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-SMLM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-PM-FFMF22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMM21-M : protocol_H----_102_C18_F1_PI_AE_Q4_CS_SP_PS_S2S.csv 1    */
/* CLASS_H-PM-FFMF21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFMS32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFLM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-SSLF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMF00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NS-SMLF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FFSM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PM-FFSF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NS-FFMF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFLF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NS-FFSS11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NS-SMLM32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PM-FFSF21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NS-FFSS22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-NF-FFSF31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSS21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFSF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-NF-FFSF31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSS22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-NF-FFSF32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFSF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMS11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FFMS21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SS-FFMM21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFLS32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-SMLM11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FFMS21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFSF32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-SMLM31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FSMM32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PM-FFMF22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMS22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMS21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSM32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMS21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FSLS33-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NS-FFSS21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSS31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSS21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FSMM32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-PM-FFSS22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-SSLF00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NS-FSLM33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMF22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PS-FFSF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PS-FFSF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-SMLF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FMLF00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FMLM31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NS-FFSF31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSF31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PS-FFLF32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSF32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSF31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-MMLM33-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FFSS11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-FFLF32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFMF32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FFMM22-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSLF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSF32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FFMM22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PS-FFSF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-NF-FFSM32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PF-FFSF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSS21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-SSLM31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSF32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFMF32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSF32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMM31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-FFLM21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PF-FFSF22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFMF32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFMF31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSS21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-FFLM21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PF-FFSF22-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFSM11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSS00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PS-FFSM32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PF-FFSF00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMM21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSLS33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSLF31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FMLM32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PS-FFSM32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-FFSF32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSF32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FFMM21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSF31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PF-FFSF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLM32-M : protocol_G-E--_200_B02_F1_AE_CS_SP_PI_S0Y.csv 1    */
/* CLASS_G-PF-FFSF11-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSF31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLM32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FMLM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PM-FFMM21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PM-FFMF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-FFSF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSMS32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLM32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PF-FFSF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSF32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLM31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-FFMM32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFSF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FSMM31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSLF32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFSF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FSMS11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLM31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FSMM31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLM31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FSLM32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSF21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMS22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSS32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FSLM31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMM21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSLM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSS11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-NF-FFSF00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FSLM32-D : protocol_G----_0030_C18_F1_PI_SE_CS_SP_S0Y.csv 1    */
/* CLASS_G-SM-FFMM21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FSLM31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-PF-FFSS22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FSLM32-M : protocol_G-E--_208_C18_F1_AE_CS_SP_PS_S0a.csv 1    */
/* CLASS_G-SM-FFSF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NS-FFMF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FSLS32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NS-FFMS21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FSLM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FSLS32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FSLS11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-PM-FFSS21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-PS-FFSS22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSF31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-NS-FFSF31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-FFLM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSF31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NS-FFSF32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FMLF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSF22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFLS31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSF31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FSLF33-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-FFLM22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSF22-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-PF-FFSF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FFMF31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FMLM33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFLM33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMM21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFSS22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FSLF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFSM21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMM21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSF00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFSM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMF32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFSS22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-PM-FFSS21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSF11-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-FFSM32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-SM-FFMM21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSF11-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-SSLM31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFLS31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PM-FFSF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFLS31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PS-FSLM32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-SSLM32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 2    */
/* CLASS_H-NM-FFMF21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-SM-FFMM21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSS00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMF21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-SSLM32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFLF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFLS32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-NS-FFSF32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMS00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSLS32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFSS21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFLS32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMS21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFMM11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PM-FFSF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSMM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMS21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMS22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PS-FFMM32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-PS-FFSF22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-PS-FFSF21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FSLM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SS-FFSF22-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFMM22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-PS-FFSF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-PS-FFSF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSLF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSMS21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFSM33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PS-FFMM32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFMM21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NS-FFMM32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FSLM33-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PS-FFMF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFSF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NS-FFSF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FMLM33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FSLM33-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-SMLF00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFSS21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFSF22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FFMF32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NS-FFMF32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-SSLM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SS-FFSM32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSF31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFMF31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFMM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFLF00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-SSLM11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSM11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-SMLF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FMLM31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-FSLF32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-SM-FFMM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-MMLM31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-MMLM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFMS11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-NM-FFSF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLF32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFSF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FSLM31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NS-FFSF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FSLM32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FSLM32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NS-FFSF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLF31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PM-FFLF33-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FSLM32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFSM22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLF32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSM33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMS21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SS-FFSF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSS11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NS-FSLM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SS-FFSF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMS21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFMM11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFMS31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SS-FFSF22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMS21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-SMLM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFLM21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFMS31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FFSS21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-SSLM33-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NS-FSMF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FMLF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFLS33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-SSLM33-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PS-FFSF21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PS-FFSF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFSM21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSS31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-SSLM21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-SSLM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PM-FFSF32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSS31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FFSF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FFSF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-SMLF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FSLS31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFMF32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PM-FFSF32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-PM-FFSF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NS-FFSF31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFSF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-PF-FFSF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PF-FFSS22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NS-FFSF32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSLS11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-NS-FFSF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-NF-FFSF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-PF-FFSF22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-PF-FFSF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSF00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSS32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-SMLM32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PF-FFSM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFMM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PS-FFSF22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMF22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMM31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PS-FFSF22-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FMLF31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-NF-FFSF32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMM31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMM31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFMS00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFSS22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PS-FFSF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-SF-FFSF32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFMM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMS22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PM-FFSF22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NS-FFSS00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FSMM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFSS21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSLS31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFMS21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NS-FFMM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NS-FFMF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-SMLM22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-SMLM21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-SMLM33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSS31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-SMLM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSS31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-SMLM33-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SS-FFSS00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFSF31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMF00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FMLM21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PM-FFMF33-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SS-FFSF31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMM32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMM32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-PM-FFMM21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFLM31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FMLM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSM11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FMLM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-NF-FFSS00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PS-FFSS21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFMF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-SMLF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SS-FFSS22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PM-FFSF31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFMS11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSM33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMF31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSS22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PS-SSLM32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFMF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSM32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PS-SSLM32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSS32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMF31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFLS31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLS00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSS33-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSS11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-FSLM32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMS21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSMM31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMS33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSMM31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMS21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-SMLF00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFSS11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NS-FFSF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-FSLM32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PM-FFMM31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-SF-FFSF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSF22-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NS-FFSS11-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-SMLM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSF00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PM-FFSF22-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSF11-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-SMLM31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-SMLM32-D : protocol_G-E--_207_C18_F1_AE_CS_SP_PS_S0U.csv 2    */
/* CLASS_G-NS-FFMS21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-SMLM31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-SMLM32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FFMM31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFLM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFSF32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-SMLS00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSLF00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PF-FFSF32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMM11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFLF31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FFMM31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFSF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSS32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-SMLF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FFLM31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSMM32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFSF21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMF32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FFMS32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSMM32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-SMLM33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFSF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-NF-FFSF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSS31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFSF22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSS32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFMM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PS-FSLM32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PM-FFSS22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PM-FFSF32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFMM21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PF-FFSF21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFLM11-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFMM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FFMM32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFLF32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSF31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FSMM21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLM21-M : protocol_G-E--_207_C18_F1_AE_Q7_CS_SP_CO_PS_S00.csv 2    */
/* CLASS_G-SF-FFMM33-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FMLS31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLF00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMM33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PM-FFMM21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FFMF22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PM-FSLM31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FMLM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFMS21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMS32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFMS21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-FFMM21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFSS33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FMLM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLM22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-SMLF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSMS00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMM33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFSM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSMF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-NF-FFSF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFMF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSS32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFMF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-FFMF32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSF11-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSF00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFMF21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMM33-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-NF-FFSF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFMF00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-NF-MMLM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NS-FFMS22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMS31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMS32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SS-FFSS21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FMLS32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SS-FFSS21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMS32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FMLM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-SSLM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PM-FFSS22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NS-FFSF00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMS32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NS-FFMM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMM11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PM-FFMF22-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFMM32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMM11-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PM-FFMF21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-SMLF00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMM11-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMS32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PM-FFMF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFSF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-FFLM32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-SSLF32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMF32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSM31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFMM31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSF32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMM31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSF32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMM31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMF32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSM33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSF11-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-SMLF00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-SSLM31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSS31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFLF00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMS31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFSS31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-SSLF00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSLF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMS31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFMS31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMM33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FFMF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMS31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-SMLM31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FFMF21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFSF22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FSLM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PS-FFSM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-FFMF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSLF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMF31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FSLM21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PM-FFMF32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFLM33-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSLM31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSM11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-FFSF00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-PF-FFSF11-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFMF22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFMM21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFMF22-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMM31-S : protocol_G-E--_060_C18_F1_PI_SE_CS_SP_CO_S0Y.csv 1    */
/* CLASS_G-SM-FSLM31-M : protocol_G-E--_200_C45_F1_SE_CS_SP_PI_CO_S0V.csv 1    */
/* CLASS_G-NS-FFSM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMF33-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFMF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FSLM21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-SF-FFSF32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFMF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSF11-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NS-FFMS00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMM32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSF31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMM32-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-SMLM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSF31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMM32-M : protocol_G-E--_107_C41_F1_PI_AE_Q4_CS_SP_PS_S0Y.csv 1    */
/* CLASS_H-NS-FFSF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFSS22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFMM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFSF31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFSS11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMM32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMM31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFMM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSLM32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-PM-FFSM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFSF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PM-FFSF21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFSF32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NS-FFSF22-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-SMLM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PM-FFSF21-M : protocol_G-E--_300_C01_S00.csv 1    */
/* CLASS_G-SF-FSLS32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-SMLM33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NS-FFSF22-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PM-FFSF21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLS32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFSS22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PF-SSLM32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SS-FFSM22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFMM33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFSS32-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SF-FFMF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NF-FFMM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFSS32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSMM11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NM-FMLF33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFSF31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NS-FFMM21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-NF-FFSM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFSF22-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-SSLS11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFSF21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NS-FFMM11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFLS21-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FFMM32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFSF31-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFSF22-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-NM-FFSF21-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-PS-FFMM21-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_U-PF-FFSF11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FMLM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_H-SM-FFSF32-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLS31-D : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-NF-FSLM11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SS-FFSS31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-SSLM00-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FFMF33-M : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SM-FFMM11-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-FSLS31-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */
/* CLASS_G-SF-SMLS33-S : protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv 0    */

#ifdef CHE_PROOFCONTROL_INTERNAL

/* Strategies used:                                       */

"G_E___207_C18_F1_AE_CS_SP_PS_S0U = \n"
"(1.ConjectureRelativeSymbolWeight(SimulateSOS,0.5,100,100,100,100,1.5,1.5,1),"
" 4.ConjectureRelativeSymbolWeight(ConstPrio,0.1,100,100,100,100,1.5,1.5,1.5),"
" 1.FIFOWeight(PreferProcessed),"
" 1.ConjectureRelativeSymbolWeight(PreferNonGoals,0.5,100,100,100,100,1.5,1.5,1),"
" 4.Refinedweight(SimulateSOS,1,1,2,1.5,2))\n"
/* Global best, protocol_G-E--_300_C18_F1_SE_CS_SP_PS_S0Y.csv, already defined */
#endif

#if defined(CHE_HEURISTICS_INTERNAL) || defined(TO_ORDERING_INTERNAL)

   else if(
      ( /* CLASS_G-SM-SMLM32-D Solved: 2 of 835 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
            res = "G_E___207_C18_F1_AE_CS_SP_PS_S0U";
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectComplexExceptRRHorn;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;
      control->heuristic_parms.presat_interreduction=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=KBO6;
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-SF-FSLM32-M Solved: 1 of 58 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
            res = "G_E___200_B02_F1_AE_CS_SP_PI_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=LPO4;
      oparms.to_prec_gen=PArity;

#endif
   }
   else if(
      ( /* CLASS_G-SF-FFMM21-M Solved: 1 of 214 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
            res = "H_____102_C18_F1_PI_AE_Q4_CS_SP_PS_S2S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectNewComplexAHP;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_fresh_defs=false;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;
      control->heuristic_parms.presat_interreduction=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=KBO6;
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_U-PM-FFSF21-M Solved: 1 of 237 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
            res = "G_E___300_C01_S00";

#endif
#ifdef TO_ORDERING_INTERNAL

#endif
   }
   else if(
      ( /* CLASS_G-SM-FFMM32-M Solved: 1 of 59 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
            res = "G_E___107_C41_F1_PI_AE_Q4_CS_SP_PS_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_fresh_defs=false;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;
      control->heuristic_parms.presat_interreduction=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=KBO6;
      oparms.to_weight_gen=WPrecRank20;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-SM-FFMM31-S Solved: 1 of 121 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
            res = "G_E___060_C18_F1_PI_SE_CS_SP_CO_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_strong_destructive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;
      control->heuristic_parms.condensing=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=KBO6;
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-SF-FSLM21-M Solved: 2 of 520 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
            res = "G_E___207_C18_F1_AE_Q7_CS_SP_CO_PS_S00";
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectNoLiterals;
      control->heuristic_parms.split_clauses=7;
      control->heuristic_parms.split_fresh_defs=false;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;
      control->heuristic_parms.presat_interreduction=true;
      control->heuristic_parms.condensing=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=KBO6;
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-SM-FSLM31-M Solved: 1 of 145 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
            res = "G_E___200_C45_F1_SE_CS_SP_PI_CO_S0V";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=PSelectComplexExceptRRHorn;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_strong_destructive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;
      control->heuristic_parms.condensing=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=KBO6;
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFreqConjMax;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_H-NM-FFMM31-D Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSF11-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SMLS00-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSF21-D Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSLM33-S Solved: 0 of 62 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMM31-M Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSS21-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSMF11-S Solved: 0 of 11 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSS21-S Solved: 0 of 28 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSMM33-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFSF22-M Solved: 0 of 13 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSS11-S Solved: 0 of 10 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMS32-S Solved: 0 of 32 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMF32-S Solved: 0 of 19 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-PM-FFMF21-M Solved: 0 of 5 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMS31-M Solved: 0 of 11 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SMLM21-S Solved: 0 of 9 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PS-SSLF32-D Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMS31-D Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSS22-S Solved: 0 of 55 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FMLM33-D Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SMLM21-M Solved: 0 of 22 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PF-FFSS32-D Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMS31-S Solved: 0 of 9 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMS32-M Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMF32-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-MMLM00-S Solved: 0 of 43 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFSF21-M Solved: 0 of 121 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMF11-S Solved: 0 of 65 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SS-FFSF21-M Solved: 0 of 6 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMS21-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-NS-FFSF11-S Solved: 0 of 4 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFLM31-M Solved: 0 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSF21-M Solved: 0 of 90 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMS22-D Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFLM32-M Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMS21-D Solved: 0 of 6 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFLM32-D Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMS22-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMM32-M Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SMLM22-S Solved: 0 of 9 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFSS21-M Solved: 0 of 9 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFSS21-D Solved: 0 of 5 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFLF32-S Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSF21-S Solved: 0 of 18 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SMLM22-M Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFMM00-S Solved: 0 of 51 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-NF-FFSF33-S Solved: 0 of 3 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLS33-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSM22-S Solved: 0 of 4 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFSS32-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSS21-M Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSS00-S Solved: 0 of 62 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PF-FFSM22-S Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-PM-FFSF22-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSM21-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-PM-FFSF22-M Solved: 0 of 15 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFMM32-M Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSS21-S Solved: 0 of 15 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLS33-S Solved: 0 of 39 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FSLM21-M Solved: 0 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFMM22-S Solved: 0 of 6 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-PM-FFSF21-S Solved: 0 of 7 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FSLM21-D Solved: 0 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FSLM22-M Solved: 0 of 13 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PM-FFSF21-M Solved: 0 of 17 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-PM-FFSF21-D Solved: 0 of 32 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMF32-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSM00-S Solved: 0 of 41 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSF33-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FSLM22-S Solved: 0 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMM21-M Solved: 0 of 8 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FSLM21-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMF31-M Solved: 0 of 46 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PS-FFSF31-M Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSMS31-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFMF11-S Solved: 0 of 5 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFSF21-S Solved: 0 of 38 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SS-FFSF32-M Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMF32-M Solved: 0 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMF32-S Solved: 0 of 25 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SS-FFSF32-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FSMM22-S Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PS-FSLF32-D Solved: 0 of 12 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SSLF33-S Solved: 0 of 10 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PS-FFSF21-S Solved: 0 of 6 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMF31-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PS-FFSF32-M Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFSF21-D Solved: 0 of 24 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-MMLM32-D Solved: 0 of 132 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLM33-S Solved: 0 of 115 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMM11-S Solved: 0 of 9 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMS22-M Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSLS00-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFMM33-S Solved: 0 of 13 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMF22-D Solved: 0 of 44 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSMF31-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMS31-M Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-MMLM11-S Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFSM33-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-SMLM00-S Solved: 0 of 11 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLM33-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSF21-M Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSM22-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSMS11-S Solved: 0 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMF33-S Solved: 0 of 79 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SMLS11-S Solved: 0 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PM-FFSF22-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMM22-M Solved: 0 of 9 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMS32-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMF21-S Solved: 0 of 11 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMS32-S Solved: 0 of 16 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMM33-S Solved: 0 of 4 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PS-FFMF32-D Solved: 0 of 28 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMM22-S Solved: 0 of 34 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSMM21-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PM-FFLM31-M Solved: 0 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PM-FFSF22-M Solved: 0 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PM-FFLM31-D Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SMLF33-S Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFSF11-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMS31-S Solved: 0 of 10 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMM00-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FMLM32-D Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMF22-S Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMS33-S Solved: 0 of 12 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFLS32-S Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FMLM32-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMM11-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFSF31-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFSF11-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMS31-D Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SSLM33-S Solved: 0 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLM11-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FMLF21-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFSS21-S Solved: 0 of 6 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SMLF33-S Solved: 0 of 35 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFMF32-D Solved: 0 of 9 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SMLM00-S Solved: 0 of 29 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMM21-S Solved: 0 of 120 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-PM-FFMF22-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-PM-FFMF21-D Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFMS32-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFLM21-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SSLF11-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMF00-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSM00-S Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSF33-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMM00-S Solved: 0 of 20 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-SMLF33-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFSM21-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PM-FFSF21-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFMF11-S Solved: 0 of 35 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFLF33-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSS11-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-SMLM32-M Solved: 0 of 210 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSM21-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PM-FFSF21-D Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSS22-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-NF-FFSF31-M Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSS21-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFSF21-M Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-NF-FFSF31-D Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSS22-S Solved: 0 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-NF-FFSF32-M Solved: 0 of 6 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFSF11-S Solved: 0 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMS11-S Solved: 0 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMS21-M Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SS-FFMM21-M Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFLS32-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SMLM11-S Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMS21-D Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFSF32-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-SMLM31-M Solved: 0 of 51 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FSMM32-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFMF22-M Solved: 0 of 5 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMS22-S Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMS21-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSM32-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMS21-S Solved: 0 of 17 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FSLS33-D Solved: 0 of 22 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSS21-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSS31-S Solved: 0 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSS21-M Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FSMM32-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-PM-FFSS22-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SSLF00-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FSLM33-S Solved: 0 of 33 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMF22-M Solved: 0 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PS-FFSF21-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PS-FFSF21-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMF22-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SMLF11-S Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FMLF00-S Solved: 0 of 25 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FMLM31-M Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSF31-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSF31-D Solved: 0 of 4 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-PS-FFLF32-D Solved: 0 of 17 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSF32-S Solved: 0 of 4 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSF31-M Solved: 0 of 8 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-MMLM33-D Solved: 0 of 36 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFSS11-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FFLF32-D Solved: 0 of 14 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFMF32-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMM22-D Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSLF11-S Solved: 0 of 39 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSF32-M Solved: 0 of 4 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMM22-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PS-FFSF11-S Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-NF-FFSM32-M Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PF-FFSF22-S Solved: 0 of 7 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSS21-D Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SSLM31-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSF32-S Solved: 0 of 12 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFMF32-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSF32-M Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMM31-M Solved: 0 of 73 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FFLM21-D Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_U-PF-FFSF22-M Solved: 0 of 74 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFMF32-D Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFMF31-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSS21-S Solved: 0 of 11 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FFLM21-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PF-FFSF22-D Solved: 0 of 34 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFSM11-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSS00-S Solved: 0 of 17 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PS-FFSM32-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSM22-S Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PF-FFSF00-S Solved: 0 of 41 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMM21-M Solved: 0 of 16 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSLS33-S Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSLF31-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FMLM32-S Solved: 0 of 13 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PS-FFSM32-M Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMF21-S Solved: 0 of 57 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FFSF32-D Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSF32-M Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMM21-M Solved: 0 of 38 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSF31-D Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_U-PF-FFSF21-S Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FFSF11-M Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSF31-M Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLM32-D Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FMLM22-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFMM21-D Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-PM-FFMF22-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FFSF11-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSMS32-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLM32-S Solved: 0 of 73 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PF-FFSF21-M Solved: 0 of 57 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSF32-S Solved: 0 of 28 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLM31-S Solved: 0 of 30 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FFMM32-S Solved: 0 of 24 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFSF11-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FSMM31-S Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSF33-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSLF32-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFSF33-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FSMS11-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLM31-D Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FSMM31-M Solved: 0 of 14 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLM31-M Solved: 0 of 113 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FSLM32-S Solved: 0 of 9 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSF21-D Solved: 0 of 9 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSF11-S Solved: 0 of 90 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMS22-S Solved: 0 of 15 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSS32-S Solved: 0 of 7 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSF21-M Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FSLM31-D Solved: 0 of 49 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMM21-D Solved: 0 of 26 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSLM00-S Solved: 0 of 98 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSF21-S Solved: 0 of 10 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSS11-S Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-NF-FFSF00-S Solved: 0 of 38 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMM21-M Solved: 0 of 51 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FSLM31-S Solved: 0 of 21 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-PF-FFSS22-S Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFSF21-M Solved: 0 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFMF21-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMM22-S Solved: 0 of 12 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FSLS32-D Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFMS21-D Solved: 0 of 10 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FSLM00-S Solved: 0 of 8 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FSLS32-M Solved: 0 of 12 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FSLS11-S Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-PM-FFSS21-S Solved: 0 of 4 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-PS-FFSS22-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSF31-D Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_U-NS-FFSF31-S Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FFLM22-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSF31-M Solved: 0 of 11 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSF32-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FMLF33-S Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSF22-S Solved: 0 of 6 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSF22-M Solved: 0 of 62 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFLS31-M Solved: 0 of 35 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSF31-S Solved: 0 of 11 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FSLF33-D Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FFLM22-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSF22-D Solved: 0 of 4 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-PF-FFSF21-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMF31-M Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FMLM33-S Solved: 0 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFLM33-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMM21-M Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFSS22-M Solved: 0 of 4 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FSLF33-S Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFSM21-M Solved: 0 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMM21-D Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSF00-S Solved: 0 of 17 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFSM21-S Solved: 0 of 13 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMF32-S Solved: 0 of 59 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSM21-S Solved: 0 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFSS22-S Solved: 0 of 12 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMM21-S Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-PM-FFSS21-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLM00-S Solved: 0 of 45 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLF33-S Solved: 0 of 17 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSF11-D Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FFSM32-S Solved: 0 of 12 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-SM-FFMM21-D Solved: 0 of 2 */
       SpecAxiomsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSF11-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMM00-S Solved: 0 of 62 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SSLM31-D Solved: 0 of 31 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFLS31-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFSF22-S Solved: 0 of 12 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFLS31-M Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMM21-S Solved: 0 of 246 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PS-FSLM32-M Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SSLM32-D Solved: 2 of 135 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMF21-D Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_U-SM-FFMM21-M Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSS00-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMF21-D Solved: 0 of 12 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SSLM32-M Solved: 0 of 52 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFLF21-M Solved: 0 of 11 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFLS32-D Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_U-NS-FFSF32-M Solved: 0 of 2 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMS00-S Solved: 0 of 18 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSLS32-S Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFSS21-S Solved: 0 of 12 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFLS32-M Solved: 0 of 11 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMS21-M Solved: 0 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFMM11-S Solved: 0 of 9 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFSF33-S Solved: 0 of 3 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMF21-M Solved: 0 of 33 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSMM00-S Solved: 0 of 139 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMS21-S Solved: 0 of 45 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMS22-M Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PS-FFMM32-S Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-PS-FFSF22-M Solved: 0 of 6 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-PS-FFSF21-D Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FSLM00-S Solved: 0 of 200 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SS-FFSF22-D Solved: 0 of 13 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFMM22-M Solved: 0 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-PS-FFSF21-M Solved: 0 of 5 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-PS-FFSF21-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSLF33-S Solved: 0 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSMS21-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFSM33-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PS-FFMM32-M Solved: 0 of 30 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFMM21-D Solved: 0 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFMM32-M Solved: 0 of 13 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FSLM33-D Solved: 0 of 348 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-PS-FFMF22-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFSF22-S Solved: 0 of 42 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFSF22-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FMLM33-S Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FSLM33-M Solved: 0 of 29 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SMLF00-S Solved: 0 of 30 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFSS21-S Solved: 0 of 9 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFSF22-M Solved: 0 of 24 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMF32-M Solved: 0 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFMF32-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-SSLM00-S Solved: 0 of 5 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SS-FFSM32-D Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSF31-S Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMF31-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMM22-S Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFMM22-S Solved: 0 of 22 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFLF00-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SSLM11-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSM11-S Solved: 0 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-SMLF33-S Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FMLM31-S Solved: 0 of 12 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FSLF32-D Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_U-SM-FFMM22-S Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-MMLM31-D Solved: 0 of 102 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-MMLM00-S Solved: 0 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFMS11-S Solved: 0 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-NM-FFSF22-S Solved: 0 of 2 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLF32-M Solved: 0 of 26 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFSF22-S Solved: 0 of 45 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FSLM31-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFSF21-S Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FSLM32-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FSLM32-M Solved: 0 of 9 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFSF21-M Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLF31-S Solved: 0 of 10 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PM-FFLF33-M Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FSLM32-D Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFSM22-M Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLF32-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSM33-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMS21-S Solved: 0 of 13 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SS-FFSF22-S Solved: 0 of 12 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSS11-S Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FSLM00-S Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SS-FFSF21-S Solved: 0 of 26 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMS21-D Solved: 0 of 31 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFMM11-S Solved: 0 of 46 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMS31-D Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-SS-FFSF22-M Solved: 0 of 8 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMS21-M Solved: 0 of 14 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-SMLM00-S Solved: 0 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFLM21-D Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMS31-M Solved: 0 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFSS21-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SSLM33-M Solved: 0 of 93 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FSMF11-S Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FMLF11-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFLS33-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SSLM33-D Solved: 0 of 9 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_U-PS-FFSF21-D Solved: 0 of 4 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_U-PS-FFSF21-M Solved: 0 of 83 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFSM21-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSS31-M Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-SSLM21-M Solved: 0 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-SSLM00-S Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFSF32-M Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSS31-D Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFSF21-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFSF21-M Solved: 0 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-SMLF33-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FSLS31-M Solved: 0 of 39 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMF32-M Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFSF32-S Solved: 0 of 6 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-PM-FFSF21-M Solved: 0 of 60 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSF31-S Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFSF21-S Solved: 0 of 32 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-PF-FFSF21-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PF-FFSS22-S Solved: 0 of 2 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMF11-S Solved: 0 of 14 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSF32-M Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSLS11-S Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-NS-FFSF22-S Solved: 0 of 4 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-NF-FFSF21-S Solved: 0 of 4 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-PF-FFSF22-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-PF-FFSF22-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSF00-S Solved: 0 of 47 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSS32-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SMLM32-M Solved: 0 of 72 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PF-FFSM21-S Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMM00-S Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PS-FFSF22-M Solved: 0 of 106 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMF22-M Solved: 0 of 13 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMM31-M Solved: 0 of 13 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PS-FFSF22-D Solved: 0 of 55 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FMLF31-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-NF-FFSF32-S Solved: 0 of 6 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMM31-D Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMF21-S Solved: 0 of 22 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMM31-S Solved: 0 of 59 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMF22-S Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFMS00-S Solved: 0 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFSS22-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PS-FFSF22-S Solved: 0 of 12 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-SF-FFSF32-S Solved: 0 of 3 */
       SpecAxiomsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFMM22-S Solved: 0 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMS22-S Solved: 0 of 30 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFSF22-M Solved: 0 of 162 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFSS00-S Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FSMM21-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFSS21-S Solved: 0 of 14 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSLS31-S Solved: 0 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFMS21-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFMM21-S Solved: 0 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFMF21-S Solved: 0 of 33 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMF21-S Solved: 0 of 49 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-SMLM22-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-SMLM21-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMF22-S Solved: 0 of 51 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SMLM33-S Solved: 0 of 106 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSS31-M Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-SMLM22-S Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSS31-D Solved: 0 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SMLM33-D Solved: 0 of 199 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-SS-FFSS00-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFSF31-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMF00-S Solved: 0 of 17 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSM21-S Solved: 0 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FMLM21-M Solved: 0 of 14 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PM-FFMF33-M Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SS-FFSF31-M Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMM32-M Solved: 0 of 31 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMM32-S Solved: 0 of 208 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-PM-FFMM21-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFLM31-M Solved: 0 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FMLM21-S Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSM11-S Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FMLM00-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-NF-FFSS00-S Solved: 0 of 2 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PS-FFSS21-M Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFMF21-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SMLF33-S Solved: 0 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SS-FFSS22-S Solved: 0 of 6 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PM-FFSF31-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFMS11-S Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSM33-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMF31-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSS22-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PS-SSLM32-M Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMF33-S Solved: 0 of 6 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSM32-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PS-SSLM32-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSS32-S Solved: 0 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMF31-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFLS31-M Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLS00-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSS33-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSS11-S Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FSLM32-D Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMS21-M Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSMM31-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMS33-S Solved: 0 of 16 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSMM31-M Solved: 0 of 15 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMS21-S Solved: 0 of 114 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SMLF00-S Solved: 0 of 10 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFSS11-S Solved: 0 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSF33-S Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FSLM32-S Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PM-FFMM31-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-SF-FFSF11-S Solved: 0 of 2 */
       SpecAxiomsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSF22-D Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSS11-D Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SMLM21-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSF00-S Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFSF22-D Solved: 0 of 46 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSF11-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSF11-S Solved: 0 of 47 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SMLM31-M Solved: 0 of 147 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSF22-S Solved: 0 of 21 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFMS21-S Solved: 0 of 11 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSF33-S Solved: 0 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SMLM31-D Solved: 0 of 25 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSF21-S Solved: 0 of 49 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SMLM32-M Solved: 0 of 122 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMM31-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSF21-S Solved: 0 of 21 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFLM00-S Solved: 0 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFSF32-S Solved: 0 of 9 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSF22-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SMLS00-S Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSF21-M Solved: 0 of 4 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSLF00-S Solved: 0 of 34 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PF-FFSF32-M Solved: 0 of 6 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMM11-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFLF31-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMM31-D Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFSF22-S Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSS32-S Solved: 0 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SMLF22-S Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFLM31-M Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSMM32-M Solved: 0 of 10 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFSF21-D Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMF32-M Solved: 0 of 15 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMS32-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSMM32-S Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SMLM33-S Solved: 0 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFSF21-S Solved: 0 of 12 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-NF-FFSF11-S Solved: 0 of 13 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSS31-D Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFSF22-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSS32-M Solved: 0 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMM21-S Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PS-FSLM32-S Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFSS22-M Solved: 0 of 3 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PM-FFSF32-M Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMM21-D Solved: 0 of 8 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSM00-S Solved: 0 of 6 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PF-FFSF21-D Solved: 0 of 112 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFLM11-D Solved: 0 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMM22-S Solved: 0 of 6 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMM32-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFLF32-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSF31-S Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FSMM21-M Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMM33-M Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FMLS31-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSM22-S Solved: 0 of 14 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLF00-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMM33-S Solved: 0 of 30 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFMM21-M Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLM21-S Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMF22-M Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PM-FSLM31-D Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FMLM21-S Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLM22-S Solved: 0 of 12 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFMS21-S Solved: 0 of 6 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMS32-D Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFMS21-D Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FFMM21-M Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFSS33-S Solved: 0 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FMLM22-S Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLM22-M Solved: 0 of 37 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SMLF22-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSMS00-S Solved: 0 of 24 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMM33-S Solved: 0 of 29 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFSM21-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSMF11-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-NF-FFSF21-M Solved: 0 of 3 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFMF21-S Solved: 0 of 31 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSS32-D Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFMF21-M Solved: 0 of 10 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FFMF32-D Solved: 0 of 18 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSF11-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSF00-S Solved: 0 of 130 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFMF21-D Solved: 0 of 29 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMM33-M Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-NF-FFSF22-S Solved: 0 of 7 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSF11-S Solved: 0 of 4 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFMF00-S Solved: 0 of 6 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-NF-MMLM00-S Solved: 0 of 2 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFMS22-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMS31-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMS32-M Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SS-FFSS21-S Solved: 0 of 6 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FMLS32-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SS-FFSS21-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMS32-S Solved: 0 of 18 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FMLM21-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SSLM22-S Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PM-FFSS22-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSF00-S Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMS32-M Solved: 0 of 16 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFMM00-S Solved: 0 of 9 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMM11-S Solved: 0 of 20 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFMF22-D Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFMM32-S Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMM11-M Solved: 0 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFMF21-D Solved: 0 of 104 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SMLF00-S Solved: 0 of 34 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMM11-D Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMS32-S Solved: 0 of 57 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFMF21-M Solved: 0 of 12 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFSF21-S Solved: 0 of 10 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FFLM32-D Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-SSLF32-D Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMF32-M Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSM31-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFMM31-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSF32-M Solved: 0 of 11 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMM31-S Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSF32-S Solved: 0 of 9 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMM31-M Solved: 0 of 11 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMF32-S Solved: 0 of 34 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSM33-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSF11-M Solved: 0 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-SMLF00-S Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-SSLM31-M Solved: 0 of 51 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSS31-D Solved: 0 of 5 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFLF00-S Solved: 0 of 13 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMS31-S Solved: 0 of 47 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSS31-M Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SSLF00-S Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSLF22-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMS31-D Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFMS31-D Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMM33-S Solved: 0 of 52 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMF21-M Solved: 0 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMS31-M Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-SMLM31-M Solved: 0 of 51 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMF21-D Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFSF22-M Solved: 0 of 5 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FSLM21-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PS-FFSM21-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FFMF11-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSLF21-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMF31-S Solved: 0 of 46 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSF22-S Solved: 0 of 88 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FSLM21-M Solved: 0 of 396 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFMF32-M Solved: 0 of 3 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFLM33-D Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSLM31-S Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMF33-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSM11-S Solved: 0 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FFSF00-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-PF-FFSF11-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMF22-M Solved: 0 of 5 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFMM21-M Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMF22-D Solved: 0 of 8 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFSM00-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMF33-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMM21-S Solved: 0 of 63 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMF21-S Solved: 0 of 6 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSF11-S Solved: 0 of 38 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FSLM21-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLF11-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-SF-FFSF32-M Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMF21-M Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSF11-D Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMF33-S Solved: 0 of 52 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSF21-S Solved: 0 of 22 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFMS00-S Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMM32-S Solved: 0 of 21 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSF31-S Solved: 0 of 5 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMM32-D Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SMLM00-S Solved: 0 of 23 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSF31-M Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSF11-S Solved: 0 of 5 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFSS22-S Solved: 0 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFMM00-S Solved: 0 of 18 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSF31-D Solved: 0 of 5 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFSS11-S Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMM32-M Solved: 0 of 12 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMM31-S Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFMM21-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSLM32-S Solved: 0 of 23 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-PM-FFSM22-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSF21-M Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFSF21-D Solved: 0 of 49 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFSF32-M Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSF22-M Solved: 0 of 22 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SMLM00-S Solved: 0 of 24 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLS32-M Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-SMLM33-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSF22-D Solved: 0 of 6 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFSF21-S Solved: 0 of 126 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLS32-S Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSS22-S Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-SSLM32-S Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SS-FFSM22-S Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMM33-S Solved: 0 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFSS32-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFMF11-S Solved: 0 of 4 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFMM21-S Solved: 0 of 28 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFSS32-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSMM11-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FMLF33-S Solved: 0 of 16 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFSF31-S Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFMM21-D Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_U-NF-FFSM00-S Solved: 0 of 2 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFSF22-S Solved: 0 of 5 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SSLS11-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFSF21-D Solved: 0 of 133 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFMM11-S Solved: 0 of 7 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFLS21-D Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMM32-S Solved: 0 of 36 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFSF31-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFSF22-D Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFSF21-M Solved: 0 of 162 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PS-FFMM21-S Solved: 0 of 183 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_U-PF-FFSF11-S Solved: 0 of 2 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FMLM00-S Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFSF32-S Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLS31-D Solved: 0 of 12 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FSLM11-S Solved: 0 of 11 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFSS31-S Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SSLM00-S Solved: 0 of 16 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMF33-M Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMM11-S Solved: 0 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FSLS31-S Solved: 0 of 12 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecShallowMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SMLS33-S Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecShallowMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
            res = "G_E___300_C18_F1_SE_CS_SP_PS_S0Y";
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_strong_destructive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;
      control->heuristic_parms.presat_interreduction=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=KBO6;
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-SM-FSLM32-M Solved: 1 of 228 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
            res = "G_E___208_C18_F1_AE_CS_SP_PS_S0a";
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectNegativeLiterals;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;
      control->heuristic_parms.presat_interreduction=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=KBO6;
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-SM-FFLM31-D Solved: 2 of 890 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
            res = "G_E___107_B42_F1_PI_SE_Q4_CS_SP_PS_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_fresh_defs=false;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_strong_destructive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;
      control->heuristic_parms.presat_interreduction=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=LPO4;
      oparms.to_prec_gen=PByInvFreqConjMax;

#endif
   }
   else if(
      ( /* CLASS_G-SM-FSLM32-D Solved: 1 of 296 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
            res = "G_____0030_C18_F1_PI_SE_CS_SP_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_strong_destructive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=KBO6;
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else /* Default */
   {
#ifdef CHE_HEURISTICS_INTERNAL
  res = "G_E___300_C18_F1_SE_CS_SP_PS_S0Y";
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_strong_destructive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;
      control->heuristic_parms.presat_interreduction=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=KBO6;
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
#endif

/* Total solutions on test set: 16 */
/* -------------------------------------------------------*/
/*     End of automatically generated code.               */
/* -------------------------------------------------------*/

