
/* -------------------------------------------------------*/
/* The following code is generated automagically with     */
/* generate_auto.py. Yes, it is fairly ugly ;-)           */
/* -------------------------------------------------------*/

/* Class dir used: ../CLASS_LISTS_PP_OPT2/ */


/* CLASS_GUSSGSSMM3  : protokoll_G-E--_081_K07_F2_PI_AE_51 3    */
/* CLASS_GHPMGFSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNMNSMMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUSFGFSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HHNMNFSMM1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNSGSSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 4    */
/* CLASS_GUNFNFFSS0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNFNFFSS1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNSGFSMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HHNFGSSSF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNFGFSMM1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNFGFSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 4    */
/* CLASS_GHSFGSSMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHSFNSSMM1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GHSFNSSMM2  : protokoll_G-E--_001_K07_F2_PI_AE_S1 17   */
/* CLASS_HUNMGSSMM3  : protokoll_H----_081_K07_F2_PI_AE_l 6    */
/* CLASS_HUNMGSSMM2  : protokoll_H----_036_K18_F2_PI_AE_S4_S1 6    */
/* CLASS_HHNMNMMMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNMGSSMM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GUNFNSMMM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHSFNFSMF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_HUNMNFFMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHSFNFSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_GUSMNSSMM3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_HUNFGSMMM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUSMNSMMM3  : protokoll_H----_031_K16_F1_PI_AE_S4_O1 2    */
/* CLASS_UHNFNFSMM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNFGFSMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_P1 1    */
/* CLASS_GHSMNFSMF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_HUNFGFFMF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_HHNSNSSMM3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 5    */
/* CLASS_HHNSNSSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HHNSNSSMM1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUPFGFFMF2  : protokoll_H----_081_K07_F2_PI_AE_l 1    */
/* CLASS_GHNFNSMLF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_UUPMNFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_HUPFGFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_GHSSNSSMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_UHPSNFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNFGFSSM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GHNFNFFSS0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNFGFFSS0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_HUNSGFFSS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUSSGFFMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNFGSSSS0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_UUPSNFFMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_GHSFNSMMM2  : protokoll_H----_031_K07_F2_PI_AE_6 8    */
/* CLASS_GHSFNSMMM3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 24   */
/* CLASS_GUNFGFSSS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHSMNSSMS1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNSGSSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHSFNSSMS2  : protokoll_H----_031_K07_F2_PI_AE_S4_S1 6    */
/* CLASS_GUSMGSMMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 6    */
/* CLASS_HUPMGFFMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNFGFSMF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHSMNFSMS1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_GUNMNSSMM3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_HUNFNFSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_O1 1    */
/* CLASS_GHSFGSMMM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 9    */
/* CLASS_UUPSGFFSS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNMNMMLM3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GHNMNMMLM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_HUNMNMMLM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 73   */
/* CLASS_GHSSGSSMS3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_GHNFNSSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GHNFNSSMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHSMGSSMM3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_GHNFNSSMF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 6    */
/* CLASS_GHNSNSSMM2  : protokoll_H----_036_K18_F2_PI_AE_S4_S1 2    */
/* CLASS_HUNSNFSSF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHPSNSSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 128  */
/* CLASS_UHNFNFFSS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNFGFSSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNFGFSSF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 4    */
/* CLASS_GHNFGFSSF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNFGFSSS0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GHNFGMMLM0  : protokoll_G-N--_023_K07_F2_PI_S4_P 7    */
/* CLASS_GHSMNSMLF3  : protokoll_H----_031_K18_F1_61  2    */
/* CLASS_GUNFGFSMS3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNMGMMLM3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNFGSSMS2  : protokoll_H----_031_K07_F2_PI_AE_5 9    */
/* CLASS_GUNFGSSMS1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNSNSMMF1  : protokoll_H----_031_K07_F2_PI_AE_Z1 7    */
/* CLASS_HUSMNFSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_HUPMNSSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNSNFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNMNFSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUSSNFFMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNSNFSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_UUPMGFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 31   */
/* CLASS_GHNSNSMMM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNFGFSMM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNFGFSMM3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNFGFSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 9    */
/* CLASS_GUPFGFFSS0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHSSNSMLS2  : protokoll_H----_031_K07_F2_PI_AE_6 17   */
/* CLASS_HUNFGSSMM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNFGSSMM2  : protokoll_H----_031_K18_F1_61  1    */
/* CLASS_HUNFGSSMM3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_GUSSGFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GUNMNSSMF2  : protokoll_H----_031_K07_F2_PI_AE_Z1 2    */
/* CLASS_GHSMNSMLM3  : protokoll_G-N--_023_K07_F2_PI_S4_O 154  */
/* CLASS_UHPSGFFMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 4    */
/* CLASS_HUNFGSMMF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNMGSMMS2  : protokoll_H----_031_K07_F2_PI_AE_Z1 2    */
/* CLASS_GUNMGSMMS3  : protokoll_H----_031_K07_F2_PI_AE_Z1 1    */
/* CLASS_GUNFGSMMF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_HUNFGSSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNMGFSMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNMGFSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_O1 8    */
/* CLASS_HUNMGFSMF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GHNFNMMMM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 9    */
/* CLASS_GUNMNSMMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_UUPMNFFMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNFGFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNFGFFSF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUSSGFSMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 12   */
/* CLASS_GUSSGFSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 8    */
/* CLASS_GHPSNSMMM2  : protokoll_H----_039_K18_F2_PI_AE_S4_S1 55   */
/* CLASS_GHNFGSSSM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GHSMNMMLS3  : protokoll_G-E--_081_K07_F2_PI_AE_Z1 3    */
/* CLASS_GHSFNSMMF3  : protokoll_H----_032_K18_F1_PI_i 4    */
/* CLASS_GHSFNSMMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_GHSSGSSMM3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_UUSMGSSMM2  : protokoll_U----_002_L07_F1_PI_PG_AE_S1 3    */
/* CLASS_UUPMGFFSF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_GHNFNMMLM3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_GHNFNMMLM0  : protokoll_H----_041_K18_F1_PI_AE_S4_S1 6    */
/* CLASS_GHNFNMMLM1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_UHPFNFFMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_GUNFGFFMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUSMNSMLS3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 6    */
/* CLASS_UUPMGFSMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 32   */
/* CLASS_GUSMNSMLF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 5    */
/* CLASS_HHSMNSSMF2  : protokoll_G-E--_082_K02_F2_PI_AE_Y 3    */
/* CLASS_UHPSGFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 9    */
/* CLASS_GHSSNSMLS3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_GUSMNMMLM3  : protokoll_H----_031_K07_F2_PI_AE_Z1 2    */
/* CLASS_GUNFNFSMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_UUNFNFFSF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 4    */
/* CLASS_UUNFNFFSF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUSMGSMMS3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 10   */
/* CLASS_UUNFNFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GHNMNSSMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 4    */
/* CLASS_UHNFNSSMM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNMGMMMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_UHPMNFFMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_HUNSGFSMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_HUNSGFSMS3  : protokoll_G-E--_001_K07_F2_PI_AE_Z1 1    */
/* CLASS_HUPMGSSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GHSMNMMLM2  : protokoll_H----_031_K07_F2_61  238  */
/* CLASS_GHSMNMMLM3  : protokoll_G-E--_070_K02_F2_AE_S1 111  */
/* CLASS_HHSFNSMLM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNFGFFSF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 6    */
/* CLASS_GHNFGFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHSSNSMLM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 6    */
/* CLASS_GHSSNSMLM3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_HHSFNSMMM1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 17   */
/* CLASS_HHSFNSMMM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_HUNMGFFSF2  : protokoll_H----_011_K01_F2_PI_6 11   */
/* CLASS_HUNFGFSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNFNFSMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNFNFSMF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNFGFFMF1  : protokoll_H----_031_K18_F1_61  1    */
/* CLASS_GUSMGSSMS3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GUSFGFSMF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_HHNFNSMMF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GUSMGSSMM2  : protokoll_U----_002_K04_F2_PI_S1 5    */
/* CLASS_HHSMNSSMS3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_UUPSNFFSF2  : protokoll_U----_043_K16_F1_PI_S1 46   */
/* CLASS_GHSMNSMMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_HUNFGFFSF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNFGFFSF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_HUNFGFFSF2  : protokoll_H----_013_K16_F2_PI_o 59   */
/* CLASS_HHNFNFFSF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_HHNFNFFSF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_GUSMNSMMS3  : protokoll_H----_031_K16_F1_PI_AE_S4_O1 3    */
/* CLASS_GUNFGFSSF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNFGFSSF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HHSFNSSMM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 6    */
/* CLASS_HHSFNSSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_HHNFGFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_GHNFNSMLM3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_HUSSGFFSS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHSFNSMLS3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUSFGFFSS0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNSNSSMS2  : protokoll_G-E--_030_K01_F2_PI_AE_Z 4    */
/* CLASS_GUNMNSMMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 24   */
/* CLASS_GHPMGFFMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_UHPFGFFMF2  : protokoll_H----_039_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GUSMGFSMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_GHNFNSMLF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 20   */
/* CLASS_HUSMGFSMM3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_HUSMGFSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 4    */
/* CLASS_GHNFNSSMM3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNFNSSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 4    */
/* CLASS_GHNFNSSMM1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GHNFNSSMM0  : protokoll_H----_031_K16_F2_PI_P 28   */
/* CLASS_GHNSNSMLF1  : protokoll_H----_031_K07_F2_PI_AE_6 1    */
/* CLASS_GUSMNSMLM3  : protokoll_U----_043_K16_F1_PI_S1 1    */
/* CLASS_GHNFNMMLF1  : protokoll_H----_031_K16_F2_PI_Y 2    */
/* CLASS_UHPFNFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 15   */
/* CLASS_GUNFNFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_HUNSNFSMM1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUSSNFSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_GUSFGSSMM1  : protokoll_H----_031_K16_F2_PI_Y 1    */
/* CLASS_GHNFGSMMM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 12   */
/* CLASS_GHNFGFSSM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNFNFSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 4    */
/* CLASS_HHNFNSMMM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUSSGFSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 16   */
/* CLASS_HHNMNSSMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUPMGFSMF2  : protokoll_U----_043_K16_F1_PI_S1 6    */
/* CLASS_GUSMNMMLS3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUSMGFSMS2  : protokoll_U----_009_L02_F1_PI_S1 22   */
/* CLASS_GUNFNFFSF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_UUPMGFSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 78   */
/* CLASS_UUPMGFSMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_HHNMNFSMS1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHSMGFFMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HHNFGFSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_HHNMNMMLS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HHNFNSMMM1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HHNFGFSSS0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNSGSMMF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUSFNFSMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HHNFGSMLM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUPMGFSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 4    */
/* CLASS_HUSMGFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 9    */
/* CLASS_HUNFGSSLF0  : protokoll_G-N--_070_K01_F2_PI_S4_AE_V 3    */
/* CLASS_GUSSNFSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_HUSMGFSMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUPSGFFMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_GHNFGMMMS0  : protokoll_H----_031_K09_F2_PI_AE_6 3    */
/* CLASS_GUNFGFSMF1  : protokoll_H----_031_K18_F1_61  2    */
/* CLASS_GUNFGFSMF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_UUPSNFFSF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHSSNSMLF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_GHSSNSMLF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HHNFNSMMS1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 4    */
/* CLASS_GHNFNFSMS0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_GHNFNFSMS1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_UUNSNFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNFNFSMS3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNFNFFMS1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNMGSMMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 4    */
/* CLASS_GUNMGSMMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GUNFGFFSS1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNFNFFSS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUSSGFFSF2  : protokoll_H----_031_K18_F1_61  13   */
/* CLASS_GUPMNFFMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_UUPFGFFMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_UUPFGFFSM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_UUPMGFFMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_HHSFNFSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GUSFGFSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHSSGSSMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_GHSFNSMMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_O1 1    */
/* CLASS_GHSFNSMMS3  : protokoll_G-E--_070_K07_F2_AE_Z1 12   */
/* CLASS_HUNMNFSMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HHNSNFSMF2  : protokoll_H----_031_K07_F2_PI_AE_Z1 1    */
/* CLASS_UHPMGFFMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNFNMMLF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_GUNSNSSMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNFGFFSM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNFNMMLF0  : protokoll_G-N--_023_K07_F2_PI_S4_P3 65   */
/* CLASS_HUNMGSMLM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_HUNMGSMLM3  : protokoll_H----_031_K18_F1_61  1    */
/* CLASS_UUPMGSSMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_UUNSNFFSF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNMGMMLM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 127  */
/* CLASS_HUSMGFSMF2  : protokoll_H----_031_K07_F2_PI_AE_S 31   */
/* CLASS_GUSSNFSMM2  : protokoll_U----_009_K18_F1_PI_AE_S1 9    */
/* CLASS_GHNSNSSMF2  : protokoll_H----_031_K16_F2_PI_Y 4    */
/* CLASS_GHNFNFSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 5    */
/* CLASS_GHNFNFSMM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 8    */
/* CLASS_HUNSGFSMF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNSGFSMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNFGSMMF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 5    */
/* CLASS_HUNSGSSMM3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNSGSSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_HUPMGFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 5    */
/* CLASS_UUPFNFFSS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HHNMNSSMM2  : protokoll_H----_031_K09_F2_PI_AE_V 3    */
/* CLASS_HUSFGFFSS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNMNFSMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNFNSSMM2  : protokoll_H----_031_K18_F1_61  26   */
/* CLASS_HHSFNFSMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GUNMGSMMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 7    */
/* CLASS_UUPFGFFSF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_UUPFGFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 13   */
/* CLASS_GHNFNMMLS3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_GHSSNMMLF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GHNFNFSSF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_GHNFNSMMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GHNFNSMMS1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GHNFNFSSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNMGSSMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 8    */
/* CLASS_HUNFGFSSS0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNFNSSLF2  : protokoll_G-N--_070_K16_F1_PI_S4_AE_S1 2    */
/* CLASS_HHNMNSMMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_UUPMGSSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 4    */
/* CLASS_HUNMGFFMF2  : protokoll_H----_072_K16_F2_PI_Y 181  */
/* CLASS_HUNFNFFSF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_HHSFNSMMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 9    */
/* CLASS_HUSSGFFMF2  : protokoll_H----_031_K18_F1_61  6    */
/* CLASS_HHNFGSMMM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNMGSMMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GHPSNFSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_UHNFGFFSS0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNMGMMLS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHSFNMMLS3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_HUNFGFFMF2  : protokoll_U----_002_L07_F0_PI_PG_AE_S1 1    */
/* CLASS_GHNFNFFMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNMGSMMM3  : protokoll_H----_031_K07_F2_PI_AE_T 2    */
/* CLASS_HUSSGFSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNFGSMMF1  : protokoll_H----_031_K09_F2_PI_AE_Z1 4    */
/* CLASS_HHPMGSSMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHSSGFSMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_GUNFGFSMS2  : protokoll_H----_031_K07_F2_PI_AE_6 3    */
/* CLASS_GUNMGSSMS1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNFGFSMS0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 14   */
/* CLASS_GUNMGSSMS3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GHSFNSMLM3  : protokoll_H----_031_K07_F2_PI_AE_Z1 31   */
/* CLASS_UUPFGFFMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_UHNSNFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUSFGSSMM3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNSGSSMS0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_HUSMGFFMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_HHNFNSSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_HHNFNSSMM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUSMGFSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNMNFSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 6    */
/* CLASS_GUNSNSSMM2  : protokoll_G-E--_001_K16_F2_PI_AE_Y1 8    */
/* CLASS_GUNMGSSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 4    */
/* CLASS_GUNMGSSMM3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_GUSSGSSMS3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 13   */
/* CLASS_GUSSGSSMS2  : protokoll_G-E--_081_K07_F2_PI_AE_Z1 4    */
/* CLASS_GHNSNFSMF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHSFNFSMF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNFNFSSF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_HUPMNFFMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_UUPMGFSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNSGFSMF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNSGFSMF2  : protokoll_G-E--_081_K07_F2_PI_AE_Z1 1    */
/* CLASS_GHSSNMMLM3  : protokoll_H----_011_K16_F2_PI_S1 3    */
/* CLASS_HUNMGSSMS1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNMGSSMS3  : protokoll_H----_031_K16_F1_PI_AE_S4_P1 1    */
/* CLASS_HUNMGSSMS2  : protokoll_G-E--_040_K18_F1_O1  6    */
/* CLASS_HUNMGSMMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 4    */
/* CLASS_GHNFNSSMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GHNFNFSMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_GHNFNFSMF2  : protokoll_H----_031_K07_F2_PI_AE_Z1 19   */
/* CLASS_GHNFNFSMF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 6    */
/* CLASS_GHNFNFSMF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNMNMMMM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHSFNFSMS2  : protokoll_H----_039_K16_F1_PI_AE_S4_S1 13   */
/* CLASS_HUSMNFSMS2  : protokoll_U----_002_K18_F1_PI_O1 1    */
/* CLASS_HUSFGFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_GHNFNSMMM1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 18   */
/* CLASS_GHNFNSMMM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 14   */
/* CLASS_GHNFNSMMM3  : protokoll_H----_031_K16_F1_PI_AE_S4_P1 21   */
/* CLASS_GHNFNSMMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 15   */
/* CLASS_HUPFGFFMS2  : protokoll_H----_081_K07_F2_PI_AE_l 1    */
/* CLASS_GHSSNMMLS3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_UUPSGFFMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_HUNSGFFSF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNSGFFSF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNSGFFSF2  : protokoll_H----_011_K07_F2_PI_V 82   */
/* CLASS_GHSMNFSMM1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNFGSMMS0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 6    */
/* CLASS_GHNFGSMMS1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GUSFGFFSF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_HHNSNSSMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNFGFFSS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HHNMNMMLF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNFGMMMM0  : protokoll_H----_031_K07_F2_PI_AE_6 5    */
/* CLASS_HUNFGFFSS0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_HUNMGSMMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_HUPMGSSMF2  : protokoll_H----_039_K18_F2_PI_AE_S4_S1 1    */
/* CLASS_GHNFNFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 4    */
/* CLASS_GHNFNFFSF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 5    */
/* CLASS_GHNFNFFSF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 13   */
/* CLASS_HUNSNFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 4    */
/* CLASS_HUNSNFFSF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GHSFNMMLM3  : protokoll_H----_035_K16_F1_PI_S1 9    */
/* CLASS_GHSFGFSMS1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNFGSSLF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNFNFSSM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GHNSNSSMM0  : protokoll_H----_031_K07_F2_PI_AE_6 6    */
/* CLASS_UUPFGFFSS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUSMGSSMF2  : protokoll_H----_031_K16_F0_PI_AE_S4_S1 21   */
/* CLASS_GUPMGFFMF2  : protokoll_U----_009_L02_F1_PI_S1 4    */
/* CLASS_UHPSNFFMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 11   */
/* CLASS_UUPMGSSMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_UUPMGSSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 10   */
/* CLASS_UHSMGSSMM2  : protokoll_H----_041_K18_F2_PI_AE_S4_S1 1    */
/* CLASS_UUPMGFFMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_UUPMGFFMF2  : protokoll_H----_041_K18_F1_PI_AE_S4_S1 74   */
/* CLASS_HHSFNMMMM1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 10   */
/* CLASS_HUSMGFFMS2  : protokoll_H----_024_K18_F2_OP_S1 2    */
/* CLASS_GUSSGFSMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNSNFSMM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNSGFFMF2  : protokoll_H----_013_K16_F2_PI_o 8    */
/* CLASS_HUSMNFFMF2  : protokoll_H----_036_K18_F2_PI_AE_S4_S1 2    */
/* CLASS_GUNFGFFSF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 6    */
/* CLASS_GUSSGSSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GUSSGSSMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 22   */
/* CLASS_HHNFNSSMM1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_HHNFNFSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_GUNFNSSMM2  : protokoll_H----_031_K16_F2_PI_Y 4    */
/* CLASS_GHNSNMMLF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUSSGFSMS2  : protokoll_G-E--_040_K18_F1_a0  11   */
/* CLASS_GUSMGFSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_HUPMGFFMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 5    */
/* CLASS_GHNFNSMMF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNMGSSMF2  : protokoll_H----_031_K16_F0_PI_AE_S4_S1 3    */
/* CLASS_GUNFGSSMM0  : protokoll_H----_011_K16_F2_PI_6 14   */
/* CLASS_GUNFGSSMM3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNFGSSMM2  : protokoll_G-N--_023_K07_F2_PI_S4_O1 100  */
/* CLASS_GUNMNFSMF2  : protokoll_G-E--_040_K16_F2_PI_S1 1    */
/* CLASS_GUNMGSSMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNMGSSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_HUNMNSMMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_HUNMNSMMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_GUNFGFSMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 10   */
/* CLASS_GUNFGFSMF2  : protokoll_H----_031_K07_F2_PI_AE_Z1 3    */
/* CLASS_HUPSGFFMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_UUNFGFFSS0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNFNSMLS1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_UUPFNFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 5    */
/* CLASS_GHNFNFSMS2  : protokoll_H----_031_K18_F1_61  7    */
/* CLASS_GHSFNFSMM1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GHSFNFSMM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_HUPSGFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 4    */
/* CLASS_GHSFNFSMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HHPFGFFMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNSGSSMM0  : protokoll_H----_031_K07_F2_PI_AE_6 3    */
/* CLASS_HUSMGSSMM2  : protokoll_H----_032_K18_F1_PI_i 11   */
/* CLASS_HUSMGSSMM3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUSSNSSMM2  : protokoll_U----_043_K16_F1_PI_S1 9    */
/* CLASS_GUNFGSSMF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNFGSSMF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_UUNMNFFSF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_UHPFGFFSF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 5    */
/* CLASS_UHPFGFFSF2  : protokoll_H----_037_K18_F2_PI_AE_S4_S1 22   */
/* CLASS_HUNFGFFMS1  : protokoll_H----_031_K18_F1_61  1    */
/* CLASS_GHNMNSSMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNMNSSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GHNFNFSSS0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNFNSMMF1  : protokoll_H----_031_K09_F2_PI_AE_Z1 28   */
/* CLASS_GHNFNSMMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_HUSMGFFSS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_UUPMGFFMM2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HHNFNFSMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUSMGSSMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 21   */
/* CLASS_UHPFGFFMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_UUPMGFFSS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNFNFFSF1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 5    */
/* CLASS_HHSMNFSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUNFGSMMM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUSMNSMMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNFNFSMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUSMGSSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GUSMGSSMF3  : protokoll_H----_031_K16_F1_PI_AE_S4_O1 18   */
/* CLASS_GUPMGFSMS2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHSFNMMMM3  : protokoll_G-E--_001_K16_F2_PI_AE_Y1 30   */
/* CLASS_GUNMGFSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_HHNMNSSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */
/* CLASS_GUSMGSSMM3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 3    */
/* CLASS_UUPSGFFSF2  : protokoll_H----_031_K10_F2_PI_AE_Z1 53   */
/* CLASS_HUNFNFSSM0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHSMNSSMM1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNFGMMLS0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 0    */
/* CLASS_GHNFNSSMS1  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUSMGFFMF2  : protokoll_H----_041_K18_F1_PI_AE_S4_S1 8    */
/* CLASS_GHNFNSSMS3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_HUNSGFSMF2  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 8    */
/* CLASS_HUNFGFSSF0  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 1    */
/* CLASS_GHNMNSMMM2  : protokoll_H----_031_K18_F1_61  10   */
/* CLASS_GHNMNSMMM3  : protokoll_H----_031_K16_F1_PI_AE_S4_S1 2    */

#ifdef CHE_PROOFCONTROL_INTERNAL

/* Strategies used:                                       */


"H_____031_K09_F2_PI_AE_Z1 = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____031_K07_F2_PI_AE_S4_S1 = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____081_K07_F2_PI_AE_l = \n"
"(8*Refinedweight(PreferGoals,1,2,2,2,2),"
" 8*Refinedweight(PreferNonGoals,2,1,2,2,0.5),"
" 1*Clauseweight(PreferUnitGroundGoals,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"U_____002_K18_F1_PI_O1 = \n"
"(20*Refinedweight(PreferGoals,4,3,2.0,1,1),"
" 5*OrientLMaxWeight(ConstPrio,2,1,2,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____031_K09_F2_PI_AE_V = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"G_E___030_K01_F2_PI_AE_Z = \n"
"(2*Clauseweight(PreferGoals,1,1,1),"
" 3*Refinedweight(PreferNonGoals,1,1,2,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"G_N___070_K16_F1_PI_S4_AE_S1 = \n"
"(3*Refinedweight(PreferGoals,1,1,2,1.5,2),"
" 3*Refinedweight(PreferNonGoals,1,1,2,1.5,0.5),"
" 1*Clauseweight(ConstPrio,1,1,1.5),"
" 1*FIFOWeight(ConstPrio))\n"
"U_____043_K16_F1_PI_S1 = \n"
"(4*PNRefinedweight(PreferNonGoals,4,5,5,4,2,1,1),"
" 8*PNRefinedweight(PreferGoals,5,2,2,5,2,1,0.5),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____032_K18_F1_PI_i = \n"
"(8*Refinedweight(PreferGoals,1,2,2,3,2),"
" 8*Refinedweight(PreferNonGoals,2,1,2,3,2),"
" 1*Clauseweight(ConstPrio,1,1,0.7),"
" 1*FIFOWeight(ByNegLitDist))\n"
"H_____011_K01_F2_PI_6 = \n"
"(8*Refinedweight(PreferGoals,1,2,2,1,0.8),"
" 8*Refinedweight(PreferNonGoals,2,1,2,3,0.8),"
" 1*Clauseweight(ConstPrio,1,1,0.7),"
" 1*FIFOWeight(ByNegLitDist))\n"
"G_E___001_K07_F2_PI_AE_Z1 = \n"
"(3*Refinedweight(PreferGoals,1,1,2,1.5,2),"
" 3*Refinedweight(PreferNonGoals,1,1,2,1.5,0.5),"
" 1*Clauseweight(ConstPrio,1,1,1.5),"
" 1*FIFOWeight(ConstPrio))\n"
"G_E___040_K18_F1_a0 = \n"
"(4*Refinedweight(SimulateSOS,1,1,2,1.5,2),"
" 3*Refinedweight(PreferNonGoals,1,1,2,1.5,1.5),"
" 1*Clauseweight(ConstPrio,1,1,2),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____031_K07_F2_PI_AE_6 = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____031_K07_F2_PI_AE_5 = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____011_K07_F2_PI_V = \n"
"(8*Refinedweight(PreferGoals,1,2,2,1,0.8),"
" 8*Refinedweight(PreferNonGoals,2,1,2,3,0.8),"
" 1*Clauseweight(ConstPrio,1,1,0.7),"
" 1*FIFOWeight(ByNegLitDist))\n"
"G_N___023_K07_F2_PI_S4_P = \n"
"(12*Clauseweight(ConstPrio,3,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____031_K07_F2_61 = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"G_E___081_K07_F2_PI_AE_Z1 = \n"
"(12*SymbolTypeweight(ConstPrio,7,20,0,0,1,5,4),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____031_K18_F1_61 = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____031_K10_F2_PI_AE_Z1 = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____035_K16_F1_PI_S1 = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*Clauseweight(ByCreationDate,-2,-1,0.5))\n"
"H_____031_K16_F2_PI_Y = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____011_K16_F2_PI_6 = \n"
"(8*Refinedweight(PreferGoals,1,2,2,1,0.8),"
" 8*Refinedweight(PreferNonGoals,2,1,2,3,0.8),"
" 1*Clauseweight(ConstPrio,1,1,0.7),"
" 1*FIFOWeight(ByNegLitDist))\n"
"G_N___023_K07_F2_PI_S4_O1 = \n"
"(12*Clauseweight(ConstPrio,3,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____011_K16_F2_PI_S1 = \n"
"(8*Refinedweight(PreferGoals,1,2,2,1,0.8),"
" 8*Refinedweight(PreferNonGoals,2,1,2,3,0.8),"
" 1*Clauseweight(ConstPrio,1,1,0.7),"
" 1*FIFOWeight(ByNegLitDist))\n"
"H_____031_K16_F1_PI_AE_S4_S1 = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"U_____002_L07_F1_PI_PG_AE_S1 = \n"
"(20*Refinedweight(PreferGoals,4,3,2.0,1,1),"
" 5*OrientLMaxWeight(ConstPrio,2,1,2,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____031_K16_F2_PI_P = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"G_E___001_K07_F2_PI_AE_S1 = \n"
"(3*Refinedweight(PreferGoals,1,1,2,1.5,2),"
" 3*Refinedweight(PreferNonGoals,1,1,2,1.5,0.5),"
" 1*Clauseweight(ConstPrio,1,1,1.5),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____039_K16_F1_PI_AE_S4_S1 = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*StaggeredWeight(ConstPrio,2))\n"
"G_N___070_K01_F2_PI_S4_AE_V = \n"
"(3*Refinedweight(PreferGoals,1,1,2,1.5,2),"
" 3*Refinedweight(PreferNonGoals,1,1,2,1.5,0.5),"
" 1*Clauseweight(ConstPrio,1,1,1.5),"
" 1*FIFOWeight(ConstPrio))\n"
"G_E___001_K16_F2_PI_AE_Y1 = \n"
"(3*Refinedweight(PreferGoals,1,1,2,1.5,2),"
" 3*Refinedweight(PreferNonGoals,1,1,2,1.5,0.5),"
" 1*Clauseweight(ConstPrio,1,1,1.5),"
" 1*FIFOWeight(ConstPrio))\n"
"G_N___023_K07_F2_PI_S4_P3 = \n"
"(12*Clauseweight(ConstPrio,3,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____013_K16_F2_PI_o = \n"
"(12*Refinedweight(PreferGoals,1,2,2,1,0.8),"
" 12*Refinedweight(PreferNonGoals,2,1,2,3,0.8),"
" 2*Clauseweight(ConstPrio,1,1,0.7))\n"
"H_____072_K16_F2_PI_Y = \n"
"(10*Refinedweight(PreferGroundGoals,2,1,2,1.0,1),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*Clauseweight(ByCreationDate,2,1,0.8))\n"
"G_E___070_K07_F2_AE_Z1 = \n"
"(3*Refinedweight(PreferGoals,1,1,1,1.5,2),"
" 3*Refinedweight(PreferNonGoals,1,1,1,1.5,0.5),"
" 1*Clauseweight(ConstPrio,1,1,1.5),"
" 1*FIFOWeight(ConstPrio))\n"
"U_____009_L02_F1_PI_S1 = \n"
"(20*Refinedweight(PreferGoals,2,1,2.0,1,1),"
" 5*OrientLMaxWeight(ConstPrio,2,1,4,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____041_K18_F1_PI_AE_S4_S1 = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*StaggeredWeight(ConstPrio,1.5))\n"
"U_____002_L07_F0_PI_PG_AE_S1 = \n"
"(20*Refinedweight(PreferGoals,4,3,2.0,1,1),"
" 5*OrientLMaxWeight(ConstPrio,2,1,2,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____036_K18_F2_PI_AE_S4_S1 = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 2*ClauseWeightAge(ConstPrio,1,1,1,3))\n"
"H_____031_K16_F0_PI_AE_S4_S1 = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____041_K18_F2_PI_AE_S4_S1 = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*StaggeredWeight(ConstPrio,1.5))\n"
"H_____031_K09_F2_PI_AE_6 = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____039_K18_F2_PI_AE_S4_S1 = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*StaggeredWeight(ConstPrio,2))\n"
"G_E___040_K18_F1_O1 = \n"
"(4*Refinedweight(SimulateSOS,1,1,2,1.5,2),"
" 3*Refinedweight(PreferNonGoals,1,1,2,1.5,1.5),"
" 1*Clauseweight(ConstPrio,1,1,2),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____037_K18_F2_PI_AE_S4_S1 = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*StaggeredWeight(ConstPrio,1))\n"
"H_____031_K07_F2_PI_AE_Z1 = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____031_K16_F1_PI_AE_S4_O1 = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"U_____009_K18_F1_PI_AE_S1 = \n"
"(20*Refinedweight(PreferGoals,2,1,2.0,1,1),"
" 5*OrientLMaxWeight(ConstPrio,2,1,4,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"G_E___081_K07_F2_PI_AE_51 = \n"
"(12*SymbolTypeweight(ConstPrio,7,20,0,0,1,5,4),"
" 1*FIFOWeight(ConstPrio))\n"
"G_E___082_K02_F2_PI_AE_Y = \n"
"(20*SymbolTypeweight(ConstPrio,3,18,0,5,1,5,3),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____024_K18_F2_OP_S1 = \n"
"(12*SymbolTypeweight(ConstPrio,7,20,0,0,1.5,5,0.8),"
" 1*FIFOWeight(ConstPrio))\n"
"U_____002_K04_F2_PI_S1 = \n"
"(20*Refinedweight(PreferGoals,4,3,2.0,1,1),"
" 5*OrientLMaxWeight(ConstPrio,2,1,2,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____031_K16_F1_PI_AE_S4_P1 = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"G_N___023_K07_F2_PI_S4_O = \n"
"(12*Clauseweight(ConstPrio,3,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"G_E___070_K02_F2_AE_S1 = \n"
"(3*Refinedweight(PreferGoals,1,1,1,1.5,2),"
" 3*Refinedweight(PreferNonGoals,1,1,1,1.5,0.5),"
" 1*Clauseweight(ConstPrio,1,1,1.5),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____031_K07_F2_PI_AE_S = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"G_E___040_K16_F2_PI_S1 = \n"
"(4*Refinedweight(SimulateSOS,1,1,2,1.5,2),"
" 3*Refinedweight(PreferNonGoals,1,1,2,1.5,1.5),"
" 1*Clauseweight(ConstPrio,1,1,2),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____031_K07_F2_PI_AE_T = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
/* Global best, protokoll_H----_031_K16_F1_PI_AE_S4_S1, already defined */
#endif

#if defined(CHE_HEURISTICS_INTERNAL) || defined(TO_ORDERING_INTERNAL)

   else if(
      ( /* CLASS_GUNFGSMMF1 Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GHNFNSMMF1 Solved: 28 of 34 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____031_K09_F2_PI_AE_Z1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=PSelectMaxLComplexNoTypePred;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WAritySqWeight;
      oparms.to_prec_gen=PArity;

#endif
   }
   else if(
      ( /* CLASS_GHSFNSSMS2 Solved: 6 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____031_K07_F2_PI_AE_S4_S1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplex;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_HUNMGSSMM3 Solved: 6 of 6 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUPFGFFMF2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUPFGFFMS2 Solved: 1 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____081_K07_F2_PI_AE_l";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=PSelectGroundNegativeLiteral;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_HUSMNFSMS2 Solved: 1 of 4 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "U_____002_K18_F1_PI_O1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectMinOptimalNoTypePred;
      control->heuristic_parms.forward_demod=1;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_HHNMNSSMM2 Solved: 3 of 4 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____031_K09_F2_PI_AE_V";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=PSelectComplexExceptRRHorn;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WAritySqWeight;
      oparms.to_prec_gen=PArity;

#endif
   }
   else if(
      ( /* CLASS_GHNSNSSMS2 Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___030_K01_F2_PI_AE_Z";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=PSelectMaxLComplex;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL

#endif
   }
   else if(
      ( /* CLASS_HUNFNSSLF2 Solved: 2 of 5 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_N___070_K16_F1_PI_S4_AE_S1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplex;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WPrecedence;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_UUPSNFFSF2 Solved: 46 of 60 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUSMNSMLM3 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUPMGFSMF2 Solved: 6 of 17 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUSSNSSMM2 Solved: 9 of 9 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "U_____043_K16_F1_PI_S1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplex;
      control->heuristic_parms.forward_demod=1;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WPrecedence;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_GHSFNSMMF3 Solved: 4 of 9 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUSMGSSMM2 Solved: 11 of 11 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____032_K18_F1_PI_i";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectDiffNegativeLiteral;
      control->heuristic_parms.forward_demod=1;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_HUNMGFFSF2 Solved: 11 of 12 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____011_K01_F2_PI_6";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=PSelectComplexExceptUniqMaxHorn;

#endif
#ifdef TO_ORDERING_INTERNAL

#endif
   }
   else if(
      ( /* CLASS_HUNSGFSMS3 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___001_K07_F2_PI_AE_Z1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=PSelectMaxLComplexNoTypePred;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_HUSSGFSMS2 Solved: 11 of 11 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___040_K18_F1_a0";
      control->heuristic_parms.selection_strategy=SelectMinInfpos;
      control->heuristic_parms.forward_demod=1;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_GHSFNSMMM2 Solved: 8 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHSSNSMLS2 Solved: 17 of 18 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNSNSMLF1 Solved: 1 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GUNFGFSMS2 Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFGMMMM0 Solved: 5 of 10 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GHNSNSSMM0 Solved: 6 of 9 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GUNSGSSMM0 Solved: 3 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____031_K07_F2_PI_AE_6";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=PSelectComplexExceptUniqMaxHorn;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_GUNFGSSMS2 Solved: 9 of 21 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____031_K07_F2_PI_AE_5";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectComplexExceptUniqMaxHorn;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_HUNSGFFSF2 Solved: 82 of 100 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____011_K07_F2_PI_V";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=PSelectComplexExceptRRHorn;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_GHNFGMMLM0 Solved: 7 of 67 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_N___023_K07_F2_PI_S4_P";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=PSelectMinOptimalLiteral;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_GHSMNMMLM2 Solved: 238 of 388 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____031_K07_F2_61";
      control->heuristic_parms.selection_strategy=PSelectNewComplexExceptUniqMaxHorn;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_GHSMNMMLS3 Solved: 3 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GUSSGSSMS2 Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUNSGFSMF2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___081_K07_F2_PI_AE_Z1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=PSelectMaxLComplexNoTypePred;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_GHSMNSMLF3 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUNFGSSMM2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNFGFFMF1 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GUNFGFSMF1 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_HUSSGFFSF2 Solved: 13 of 15 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNMGSMLM3 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUNFNSSMM2 Solved: 26 of 26 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUSSGFFMF2 Solved: 6 of 8 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFNFSMS2 Solved: 7 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNFGFFMS1 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GHNMNSMMM2 Solved: 10 of 10 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____031_K18_F1_61";
      control->heuristic_parms.selection_strategy=PSelectNewComplexExceptUniqMaxHorn;
      control->heuristic_parms.forward_demod=1;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WPrecedence;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_UUPSGFFSF2 Solved: 53 of 61 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____031_K10_F2_PI_AE_Z1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=PSelectMaxLComplexNoTypePred;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WSelectMaximal;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_GHSFNMMLM3 Solved: 9 of 54 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____035_K16_F1_PI_S1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=PSelectNewComplex;
      control->heuristic_parms.forward_demod=1;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WPrecedence;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_GHNFNMMLF1 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GUSFGSSMM1 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GHNSNSSMF2 Solved: 4 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUNFNSSMM2 Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____031_K16_F2_PI_Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplex;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WPrecedence;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_GUNFGSSMM0 Solved: 14 of 29 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____011_K16_F2_PI_6";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=PSelectComplexExceptUniqMaxHorn;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WPrecedence;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_GUNFGSSMM2 Solved: 100 of 256 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_N___023_K07_F2_PI_S4_O1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectMinOptimalNoTypePred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_GHSSNMMLM3 Solved: 3 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____011_K16_F2_PI_S1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplex;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WPrecedence;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_GHPMGFSMF2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNMNSMMS2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUSFGFSMF2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HHNMNFSMM1 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GUNSGSSMM2 Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUNFNFFSS0 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GUNFNFFSS1 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GUNSGFSMS2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HHNFGSSSF0 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GUNFGFSMM1 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GUNFGFSMM2 Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHSFGSSMS2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHSFNSSMM1 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_HHNMNMMMF2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNMGSSMM0 Solved: 2 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GUNFNSMMM0 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GHSFNFSMF0 Solved: 2 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HUNMNFFMF2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHSFNFSMF2 Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUSMNSSMM3 Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUNFGSMMM0 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_UHNFNFSMM0 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GHSMNFSMF1 Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_HUNFGFFMF0 Solved: 2 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HHNSNSSMM3 Solved: 5 of 5 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HHNSNSSMM2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HHNSNSSMM1 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GHNFNSMLF1 Solved: 2 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_UUPMNFFSF2 Solved: 2 of 2 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUPFGFFSF2 Solved: 0 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHSSNSSMF3 Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_UHPSNFFSF2 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNFGFSSM0 Solved: 2 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GHNFNFFSS0 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GHNFGFFSS0 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HUNSGFFSS2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUSSGFFMM2 Solved: 1 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNFGSSSS0 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_UUPSNFFMF2 Solved: 0 of 3 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHSFNSMMM3 Solved: 24 of 36 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GUNFGFSSS2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHSMNSSMS1 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GUNSGSSMF2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUSMGSMMF3 Solved: 6 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUPMGFFMS2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFGFSMF0 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GHSMNFSMS1 Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GUNMNSSMM3 Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GHSFGSMMM0 Solved: 9 of 9 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_UUPSGFFSS2 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNMNMMLM3 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GHNMNMMLM2 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNMNMMLM0 Solved: 73 of 73 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GHSSGSSMS3 Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GHNFNSSMF2 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFNSSMF3 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GHSMGSSMM3 Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GHNFNSSMF1 Solved: 6 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_HUNSNFSSF1 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GHPSNSSMM2 Solved: 128 of 128 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UHNFNFFSS2 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFGFSSF2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFGFSSF0 Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GHNFGFSSF1 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GHNFGFSSS0 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GUNFGFSMS3 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GUNMGMMLM3 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GUNFGSSMS1 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_HUSMNFSMF2 Solved: 0 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUPMNSSMF2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUNSNFFSF2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNMNFSMF2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUSSNFFMM2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNSNFSMF2 Solved: 2 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UUPMGFFSF2 Solved: 31 of 35 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNSNSMMM0 Solved: 1 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HUNFGFSMM0 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HUNFGFSMM3 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUNFGFSMM2 Solved: 9 of 9 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUPFGFFSS0 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HUNFGSSMM0 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HUNFGSSMM3 Solved: 0 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GUSSGFFSF2 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UHPSGFFMF2 Solved: 4 of 4 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNFGSMMF0 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GUNFGSMMF0 Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HUNFGSSMF2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNMGFSMF3 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUNMGFSMF1 Solved: 2 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GHNFNMMMM0 Solved: 9 of 10 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GUNMNSMMF2 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UUPMNFFMF2 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUNFGFFSF2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUNFGFFSF3 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GUSSGFSMF3 Solved: 12 of 18 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GUSSGFSMF2 Solved: 8 of 9 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFGSSSM0 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GHSFNSMMF2 Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHSSGSSMM3 Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_UUPMGFFSF3 Solved: 3 of 5 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GHNFNMMLM3 Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GHNFNMMLM1 Solved: 0 of 11 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_UHPFNFFMF2 Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUNFGFFMF3 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GUSMNSMLS3 Solved: 6 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_UUPMGFSMS2 Solved: 32 of 34 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUSMNSMLF3 Solved: 5 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_UHPSGFFSF2 Solved: 9 of 9 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHSSNSMLS3 Solved: 3 of 20 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GUNFNFSMS2 Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UUNFNFFSF1 Solved: 4 of 4 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_UUNFNFFSF0 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GUSMGSMMS3 Solved: 10 of 10 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_UUNFNFFSF2 Solved: 2 of 2 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNMNSSMS2 Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UHNFNSSMM0 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GUNMGMMMM2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UHPMNFFMF2 Solved: 2 of 2 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNSGFSMS2 Solved: 3 of 3 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUPMGSSMM2 Solved: 2 of 3 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HHSFNSMLM2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFGFFSF0 Solved: 6 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GHNFGFFSF2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHSSNSMLM2 Solved: 6 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHSSNSMLM3 Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HHSFNSMMM1 Solved: 17 of 17 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_HHSFNSMMM0 Solved: 3 of 3 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HUNFGFSMF2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNFNFSMF3 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUNFNFSMF1 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GUSMGSSMS3 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GUSFGFSMF1 Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_HHNFNSMMF1 Solved: 2 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_HHSMNSSMS3 Solved: 2 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GHSMNSMMF3 Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUNFGFFSF1 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_HUNFGFFSF0 Solved: 3 of 3 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HHNFNFFSF1 Solved: 2 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_HHNFNFFSF0 Solved: 3 of 3 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GUNFGFSSF1 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GUNFGFSSF0 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HHSFNSSMM0 Solved: 6 of 6 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HHSFNSSMM2 Solved: 2 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HHNFGFFSF2 Solved: 0 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFNSMLM3 Solved: 0 of 10 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUSSGFFSS2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHSFNSMLS3 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GUSFGFFSS0 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GUNMNSMMM2 Solved: 24 of 24 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHPMGFFMF2 Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUSMGFSMS2 Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFNSMLF0 Solved: 20 of 20 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HUSMGFSMM3 Solved: 0 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUSMGFSMM2 Solved: 4 of 5 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFNSSMM3 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GHNFNSSMM2 Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFNSSMM1 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_UHPFNFFSF2 Solved: 15 of 15 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUNFNFFSF2 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNSNFSMM1 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_HUSSNFSMF2 Solved: 3 of 3 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFGSMMM0 Solved: 12 of 12 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GHNFGFSSM0 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GUNFNFSMF2 Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HHNFNSMMM0 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HUSSGFSMF2 Solved: 16 of 20 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HHNMNSSMS2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUSMNMMLS3 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GUNFNFFSF0 Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_UUPMGFSMF2 Solved: 78 of 93 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UUPMGFSMF3 Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HHNMNFSMS1 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GHSMGFFMF2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HHNFGFSMM2 Solved: 2 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HHNMNMMLS2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HHNFNSMMM1 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_HHNFGFSSS0 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GUNSGSMMF1 Solved: 1 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GUSFNFSMS2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HHNFGSMLM0 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HUPMGFSMM2 Solved: 4 of 4 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUSMGFFSF2 Solved: 9 of 12 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUSSNFSMF2 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUSMGFSMF3 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUPSGFFMS2 Solved: 0 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUNFGFSMF0 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_UUPSNFFSF1 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GHSSNSMLF3 Solved: 3 of 10 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GHSSNSMLF2 Solved: 1 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HHNFNSMMS1 Solved: 4 of 4 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GHNFNFSMS0 Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GHNFNFSMS1 Solved: 2 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_UUNSNFFSF2 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFNFSMS3 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUNFNFFMS1 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GUNMGSMMF3 Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GUNMGSMMF2 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUNFGFFSS1 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_HUNFNFFSS2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUPMNFFMF2 Solved: 1 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UUPFGFFMF2 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UUPFGFFSM2 Solved: 2 of 2 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UUPMGFFMS2 Solved: 3 of 3 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HHSFNFSMM2 Solved: 2 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUSFGFSMM2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHSSGSSMF3 Solved: 3 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUNMNFSMS2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UHPMGFFMF2 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFNMMLF3 Solved: 0 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GUNSNSSMF3 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUNFGFFSM0 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HUNMGSMLM2 Solved: 2 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UUPMGSSMS2 Solved: 3 of 3 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UUNSNFFSF1 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_HUNMGMMLM0 Solved: 127 of 127 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GHNFNFSMM2 Solved: 5 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFNFSMM0 Solved: 8 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HUNSGFSMF1 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_HUNSGFSMF3 Solved: 1 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GHNFGSMMF0 Solved: 5 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HUNSGSSMM3 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUNSGSSMM2 Solved: 2 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUPMGFFSF2 Solved: 5 of 6 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UUPFNFFSS2 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUSFGFFSS2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUNMNFSMS2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HHSFNFSMS2 Solved: 2 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUNMGSMMM2 Solved: 7 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UUPFGFFSF1 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_UUPFGFFSF2 Solved: 13 of 14 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFNMMLS3 Solved: 0 of 10 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GHSSNMMLF3 Solved: 2 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GHNFNFSSF1 Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GHNFNSMMS2 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFNSMMS1 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GHNFNFSSF2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUNMGSSMS2 Solved: 8 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNFGFSSS0 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HHNMNSMMF2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UUPMGSSMM2 Solved: 4 of 4 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNFNFFSF1 Solved: 2 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_HHSFNSMMM2 Solved: 9 of 9 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HHNFGSMMM0 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HUNMGSMMS2 Solved: 2 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHPSNFSMM2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UHNFGFFSS0 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HUNMGMMLS2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHSFNMMLS3 Solved: 3 of 11 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GHNFNFFMF2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUSSGFSMM2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HHPMGSSMS2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHSSGFSMF3 Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GUNMGSSMS1 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GUNFGFSMS0 Solved: 14 of 14 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GUNMGSSMS3 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_UUPFGFFMM2 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UHNSNFFSF2 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUSFGSSMM3 Solved: 1 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GUNSGSSMS0 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HUSMGFFMM2 Solved: 0 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HHNFNSSMM2 Solved: 3 of 3 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HHNFNSSMM0 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GUSMGFSMF2 Solved: 1 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNMNFSMF2 Solved: 6 of 7 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUNMGSSMM2 Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUNMGSSMM3 Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GUSSGSSMS3 Solved: 13 of 28 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GHNSNFSMF1 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GHSFNFSMF1 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GHNFNFSSF0 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HUPMNFFMF2 Solved: 0 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UUPMGFSMM2 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUNSGFSMF1 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_HUNMGSSMS1 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_HUNMGSMMM2 Solved: 4 of 4 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFNSSMS2 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFNFSMF3 Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GHNFNFSMF1 Solved: 6 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GHNFNFSMF0 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GHNMNMMMM0 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HUSFGFFSF2 Solved: 0 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFNSMMM1 Solved: 18 of 18 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GHNFNSMMM0 Solved: 14 of 15 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GHNFNSMMM2 Solved: 15 of 15 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHSSNMMLS3 Solved: 0 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_UUPSGFFMF2 Solved: 2 of 12 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNSGFFSF0 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HUNSGFFSF1 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GHSMNFSMM1 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GHNFGSMMS0 Solved: 6 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GHNFGSMMS1 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GUSFGFFSF1 Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_HHNSNSSMS2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNFGFFSS2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HHNMNMMLF2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNFGFFSS0 Solved: 2 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HUNMGSMMF2 Solved: 2 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFNFFSF2 Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFNFFSF0 Solved: 5 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GHNFNFFSF1 Solved: 13 of 14 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_HUNSNFFSF2 Solved: 4 of 4 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNSNFFSF1 Solved: 2 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GHSFGFSMS1 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_HUNFGSSLF2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFNFSSM0 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_UUPFGFFSS2 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UHPSNFFMF2 Solved: 11 of 11 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UUPMGSSMF3 Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_UUPMGSSMF2 Solved: 10 of 23 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UUPMGFFMF3 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HHSFNMMMM1 Solved: 10 of 10 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GUSSGFSMS2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNSNFSMM0 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GUNFGFFSF0 Solved: 6 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GUSSGSSMF2 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUSSGSSMF3 Solved: 22 of 29 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HHNFNSSMM1 Solved: 3 of 3 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_HHNFNFSMM2 Solved: 3 of 3 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNSNMMLF3 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GUSMGFSMM2 Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUPMGFFMF2 Solved: 5 of 7 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFNSMMF0 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GUNFGSSMM3 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GUNMGSSMF3 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GUNMGSSMF2 Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNMNSMMF3 Solved: 3 of 3 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUNMNSMMF2 Solved: 3 of 3 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUNFGFSMF3 Solved: 10 of 10 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUPSGFFMF2 Solved: 2 of 5 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UUNFGFFSS0 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GHNFNSMLS1 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_UUPFNFFSF2 Solved: 5 of 5 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHSFNFSMM1 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GHSFNFSMM0 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_HUPSGFFSF2 Solved: 4 of 5 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHSFNFSMM2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HHPFGFFMF2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUSMGSSMM3 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GUNFGSSMF0 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GUNFGSSMF1 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_UUNMNFFSF2 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UHPFGFFSF0 Solved: 5 of 5 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GHNMNSSMF3 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GHNMNSSMF2 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNFNFSSS0 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GHNFNSMMF2 Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUSMGFFSS2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UUPMGFFMM2 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HHNFNFSMS2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUSMGSSMS2 Solved: 21 of 21 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_UHPFGFFMF3 Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_UUPMGFFSS2 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUNFNFFSF1 Solved: 5 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_HHSMNFSMF2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUNFGSMMM0 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GUSMNSMMF3 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUNFNFSMS2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUSMGSSMF2 Solved: 1 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUPMGFSMS2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUNMGFSMF2 Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HHNMNSSMF2 Solved: 2 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUSMGSSMM3 Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUNFNFSSM0 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GHSMNSSMM1 Solved: 1 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GHNFGMMLS0 Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GHNFNSSMS1 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GHNFNSSMS3 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUNSGFSMF2 Solved: 8 of 9 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNFGFSSF0 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_GHNMNSMMM3 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____031_K16_F1_PI_AE_S4_S1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplex;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WPrecedence;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_UUSMGSSMM2 Solved: 3 of 3 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "U_____002_L07_F1_PI_PG_AE_S1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplex;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.prefer_general=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=LPO;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_GHNFNSSMM0 Solved: 28 of 41 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____031_K16_F2_PI_P";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=PSelectMinOptimalLiteral;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WPrecedence;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_GHSFNSSMM2 Solved: 17 of 17 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___001_K07_F2_PI_AE_S1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplex;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_UHPFGFFMF2 Solved: 2 of 2 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHSFNFSMS2 Solved: 13 of 14 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____039_K16_F1_PI_AE_S4_S1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplex;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WPrecedence;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_HUNFGSSLF0 Solved: 3 of 3 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_N___070_K01_F2_PI_S4_AE_V";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=PSelectComplexExceptRRHorn;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL

#endif
   }
   else if(
      ( /* CLASS_GUNSNSSMM2 Solved: 8 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHSFNMMMM3 Solved: 30 of 30 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___001_K16_F2_PI_AE_Y1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexNoTypePred;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WPrecedence;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_GHNFNMMLF0 Solved: 65 of 72 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_N___023_K07_F2_PI_S4_P3";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=PSelectMinOptimalNoRXTypePred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_HUNFGFFSF2 Solved: 59 of 69 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNSGFFMF2 Solved: 8 of 10 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____013_K16_F2_PI_o";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectCondOptimalLiteral;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WPrecedence;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_HUNMGFFMF2 Solved: 181 of 278 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____072_K16_F2_PI_Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplex;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WPrecedence;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_GHSFNSMMS3 Solved: 12 of 25 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___070_K07_F2_AE_Z1";
      control->heuristic_parms.selection_strategy=PSelectMaxLComplexNoTypePred;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_HUSMGFSMS2 Solved: 22 of 23 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUPMGFFMF2 Solved: 4 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "U_____009_L02_F1_PI_S1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplex;
      control->heuristic_parms.forward_demod=1;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=LPO;
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PArity;

#endif
   }
   else if(
      ( /* CLASS_GHNFNMMLM0 Solved: 6 of 27 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec))
       ||
      ( /* CLASS_UUPMGFFMF2 Solved: 74 of 115 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUSMGFFMF2 Solved: 8 of 14 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____041_K18_F1_PI_AE_S4_S1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplex;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_HUNFGFFMF2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "U_____002_L07_F0_PI_PG_AE_S1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplex;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=0;
      control->heuristic_parms.prefer_general=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=LPO;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_HUNMGSSMM2 Solved: 6 of 6 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHNSNSSMM2 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUSMNFFMF2 Solved: 2 of 2 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____036_K18_F2_PI_AE_S4_S1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplex;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_HUSMGSSMF2 Solved: 21 of 24 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNMGSSMF2 Solved: 3 of 4 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____031_K16_F0_PI_AE_S4_S1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplex;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=0;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WPrecedence;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_UHSMGSSMM2 Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____041_K18_F2_PI_AE_S4_S1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplex;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_GHNFGMMMS0 Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____031_K09_F2_PI_AE_6";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=PSelectComplexExceptUniqMaxHorn;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WAritySqWeight;
      oparms.to_prec_gen=PArity;

#endif
   }
   else if(
      ( /* CLASS_GHPSNSMMM2 Solved: 55 of 55 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUPMGSSMF2 Solved: 1 of 5 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____039_K18_F2_PI_AE_S4_S1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplex;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_HUNMGSSMS2 Solved: 6 of 6 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___040_K18_F1_O1";
      control->heuristic_parms.selection_strategy=SelectMinOptimalNoTypePred;
      control->heuristic_parms.forward_demod=1;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_UHPFGFFSF2 Solved: 22 of 48 */
       SpecAxiomsAreUnit(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____037_K18_F2_PI_AE_S4_S1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplex;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_GHNSNSMMF1 Solved: 7 of 31 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec))
       ||
      ( /* CLASS_GUNMNSSMF2 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUNMGSMMS2 Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUNMGSMMS3 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GUSMNMMLM3 Solved: 2 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HHNSNFSMF2 Solved: 1 of 3 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GHSFNSMLM3 Solved: 31 of 31 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GHNFNFSMF2 Solved: 19 of 19 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUNFGFSMF2 Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____031_K07_F2_PI_AE_Z1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=PSelectMaxLComplexNoTypePred;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_GUSMNSMMM3 Solved: 2 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_HUNFNFSMM2 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNMGFSMF2 Solved: 8 of 12 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUSMNSMMS3 Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GHSFNSMMS2 Solved: 1 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_GUSMGSSMF3 Solved: 18 of 20 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____031_K16_F1_PI_AE_S4_O1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectMinOptimalNoTypePred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WPrecedence;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_GUSSNFSMM2 Solved: 9 of 9 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "U_____009_K18_F1_PI_AE_S1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplex;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_GUSSGSSMM3 Solved: 3 of 9 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___081_K07_F2_PI_AE_51";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplexExceptUniqMaxHorn;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_HHSMNSSMF2 Solved: 3 of 3 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___082_K02_F2_PI_AE_Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplex;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PArity;

#endif
   }
   else if(
      ( /* CLASS_HUSMGFFMS2 Solved: 2 of 5 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____024_K18_F2_OP_S1";
      control->heuristic_parms.selection_strategy=SelectNewComplex;
      control->heuristic_parms.select_on_proc_only=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_GUSMGSSMM2 Solved: 5 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "U_____002_K04_F2_PI_S1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplex;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WArityWeight ;
      oparms.to_prec_gen=PArity;

#endif
   }
   else if(
      ( /* CLASS_GHNFGFSMS2 Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec))
       ||
      ( /* CLASS_HUNMGSSMS3 Solved: 1 of 1 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec))
       ||
      ( /* CLASS_GHNFNSMMM3 Solved: 21 of 46 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____031_K16_F1_PI_AE_S4_P1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=PSelectMinOptimalNoTypePred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WPrecedence;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_GHSMNSMLM3 Solved: 154 of 554 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_N___023_K07_F2_PI_S4_O";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectMinOptimalLiteral;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_GHSMNMMLM3 Solved: 111 of 414 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___070_K02_F2_AE_S1";
      control->heuristic_parms.selection_strategy=SelectNewComplex;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PArity;

#endif
   }
   else if(
      ( /* CLASS_HUSMGFSMF2 Solved: 31 of 36 */
       SpecAxiomsAreHorn(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____031_K07_F2_PI_AE_S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectComplex;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_GUNMNFSMF2 Solved: 1 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsHaveVars(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___040_K16_F2_PI_S1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplex;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WPrecedence;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_GUNMGSMMM3 Solved: 2 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecGoalsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecGoalsAreGround(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____031_K07_F2_PI_AE_T";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=PSelectComplex;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else /* Default */
   {
#ifdef CHE_HEURISTICS_INTERNAL
  res = "H_____031_K16_F1_PI_AE_S4_S1";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplex;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WPrecedence;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
#endif

/* Total solutions on test set: 3358 */
/* -------------------------------------------------------*/
/*     End of automatically generated code.               */
/* -------------------------------------------------------*/

