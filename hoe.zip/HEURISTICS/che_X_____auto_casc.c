
/* -------------------------------------------------------*/
/* The following code is generated automagically with     */
/* generate_auto.py. Yes, it is fairly ugly ;-)           */
/* -------------------------------------------------------*/

/* Class dir used: ../CLASS_LISTS_NC4/ */


/* CLASS_G-SF-FFSS11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 4    */
/* CLASS_H-NS-FFSF11-M : protokoll_G-E--_045_K18_F1_PI_AE_S4_CS_SP_S0Y 5    */
/* CLASS_H-NS-FFSF21-D : protokoll_H----_011_K07_F1_PI_AE_SP_SOV 12   */
/* CLASS_H-NS-FFSF11-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NF-MMMS00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_G-SF-FFSS21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 6    */
/* CLASS_G-NF-FSMF11-M : protokoll_H----_031_K09_F1_PI_AE_SP_S0Y 12   */
/* CLASS_G-SF-SSMF32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_H-SM-FFSF22-M : protokoll_H----_042_B03_F1_PI_AE_SP_S2S 33   */
/* CLASS_G-SF-SSMF31-M : protokoll_G-E--_006_K18_F1_PI_AE_S4_CS_SP_S0Y 3    */
/* CLASS_G-NM-SSMS22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NF-FFSS22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NF-FFMF31-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-SF-SFMM21-M : protokoll_H----_024_K18_F1_PI_OP_AE_S4_CS_SP_S2S 10   */
/* CLASS_G-NF-SFMM00-M : protokoll_H----_102_K18_F1_PI_AE_S4_CS_S1S 7    */
/* CLASS_G-NF-FFMF32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-SS-MMLM22-M : protokoll_G-E--_001_K18_F1_PI_AE_S4_CS_SP_S2S 11   */
/* CLASS_H-NS-FFSF21-M : protokoll_H----_011_K07_F1_PI_AE_S4_CS_SP_SOV 87   */
/* CLASS_G-SF-SMMM31-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 9    */
/* CLASS_H-NF-SFMM00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-SS-SSMM32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_G-SF-SSMS32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 20   */
/* CLASS_G-NF-FFMF11-M : protokoll_G-E--_045_K18_F1_PI_AE_S4_SP_S0Y 25   */
/* CLASS_H-SF-SFMF11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 4    */
/* CLASS_H-NM-FFMS21-D : protokoll_H----_081_K18_F1_PI_AE_S4_CS_SP_S2S 3    */
/* CLASS_H-SM-FFSS21-D : protokoll_H----_102_K18_F1_PI_AE_S4_CS_S1S 2    */
/* CLASS_H-NF-SFMS11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_H-SM-FFSF22-D : protokoll_H----_036_K18_F2_PI_AE_S4_SP_S2S 1    */
/* CLASS_G-NF-FFMS21-M : protokoll_H----_102_K18_F1_PI_AE_S4_CS_SP_S2S 60   */
/* CLASS_G-NS-FFMF32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NF-FFSS21-M : protokoll_H----_031_K18_F1_PI_AE_CS_SP_S3T 16   */
/* CLASS_H-PM-FFSF22-M : protokoll_H----_042_B30_F1_PI_AE_SP_S2S 12   */
/* CLASS_G-NF-FFSS00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 35   */
/* CLASS_H-SF-FFSM22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 4    */
/* CLASS_G-SM-SFMM33-M : protokoll_G-E--_045_K18_F1_PI_AE_S4_SP_S0Y 1    */
/* CLASS_H-NM-SSMS22-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NS-FFMF11-M : protokoll_G-E--_045_K18_F1_PI_AE_S4_SP_S0Y 4    */
/* CLASS_H-SF-FFSF33-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 1    */
/* CLASS_H-SF-SSMM11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 39   */
/* CLASS_G-SF-SMMM21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S 202  */
/* CLASS_H-PM-FFSF21-D : protokoll_H----_047_K18_F1_PI_AE_S4_CS_SP_S2S 1    */
/* CLASS_H-PM-FFSF21-M : protokoll_H----_047_K18_F1_PI_AE_S4_CS_SP_S2S 6    */
/* CLASS_G-NF-FFSF31-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 3    */
/* CLASS_G-NF-SSLF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-SF-SSLF33-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-SM-FFMF32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 1    */
/* CLASS_H-SM-FFSF21-M : protokoll_G-E--_012_K18_F1_PI_AE_S4_CS_SP_S0Y 22   */
/* CLASS_G-NM-SFMF22-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 3    */
/* CLASS_H-NF-FFMF11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-NM-SFMF22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_H-SM-FFSF21-D : protokoll_G-E--_007_K18_F1_PI_AE_S4_CS_SP_S0Y 6    */
/* CLASS_G-NM-FFMS22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NF-MMLM21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_H-SM-FFSM33-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_G-NS-SSMF32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-SF-FFSF21-M : protokoll_H----_081_B02_F1_PI_AE_S4_CS_SP_S2S 18   */
/* CLASS_H-SF-FFSS31-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-SF-FFMS31-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NS-FFMM00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 3    */
/* CLASS_G-SF-FFMM22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 6    */
/* CLASS_G-NF-FFMS32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 3    */
/* CLASS_G-SS-FFMF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 7    */
/* CLASS_G-PM-FFSF22-M : protokoll_G-E--_045_B07_F1_PI_AE_S4_CS_SP_S0Y 1    */
/* CLASS_G-SF-SSLM33-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_G-SM-FFSS11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 5    */
/* CLASS_G-SM-FFMS33-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-SF-FFMF22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 10   */
/* CLASS_G-NF-FFMS31-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 3    */
/* CLASS_G-NF-MMLM22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NS-FFSF11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-SS-SSMS21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 18   */
/* CLASS_G-SF-FFSM00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 4    */
/* CLASS_G-SM-MSMM22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-SF-FFMM21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 17   */
/* CLASS_H-PM-FFMF21-D : protokoll_H----_047_K18_F1_PI_AE_S4_CS_SP_S2S 2    */
/* CLASS_G-NM-SFMM21-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 34   */
/* CLASS_G-NM-SFMM21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_H-SM-FFSS22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 10   */
/* CLASS_G-PM-FFSF21-M : protokoll_G-E--_006_K18_F1_PI_AE_S4_CS_SP_S0Y 4    */
/* CLASS_G-NS-FFMF11-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-PM-FFSF21-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 1    */
/* CLASS_H-NF-SSMF00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-SM-SMMM21-M : protokoll_G-E--_044_K18_F1_PI_AE_S4_CS_SP_S2S 168  */
/* CLASS_G-PF-MSLM22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-SM-SMMM21-D : protokoll_G-E--_003_K18_F1_PI_AE_S4_CS_SP_S2S 6    */
/* CLASS_H-NM-SFMF22-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 6    */
/* CLASS_H-NM-FFSF11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 3    */
/* CLASS_G-NM-FFMS21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 4    */
/* CLASS_H-NF-FFSS22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-SF-SFMM32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 22   */
/* CLASS_H-NM-SFMF22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NM-FFMS21-D : protokoll_G-E--_045_K18_F1_PI_AE_S4_CS_SP_S0Y 3    */
/* CLASS_G-SM-SFMM31-D : protokoll_G-E--_003_K18_F1_PI_AE_S4_CS_OS_S0Y_backup 82   */
/* CLASS_H-NF-FFSS21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-PF-MSLM21-M : protokoll_G-E--_001_K18_F1_PI_AE_S4_CS_SP_S2S 1    */
/* CLASS_G-SF-SFMF31-M : protokoll_H----_042_B07_F1_PI_AE_SP_S2S 5    */
/* CLASS_G-SS-FFMS21-M : protokoll_G-E--_007_K18_F1_PI_AE_S4_CS_SP_S0Y 3    */
/* CLASS_U-PM-FFSF32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 4    */
/* CLASS_G-NF-SFMF11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 3    */
/* CLASS_H-SF-SFMM00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 16   */
/* CLASS_G-NS-SSMF11-M : protokoll_U----_043_K09_F1_PI_AE_CS_SP_S0Y 6    */
/* CLASS_G-SS-FFMF22-M : protokoll_G-E--_012_K18_F1_PI_AE_S4_CS_SP_S0Y 14   */
/* CLASS_G-NF-MMLM00-M : protokoll_H----_011_K07_F1_PI_AE_SP_SOV 31   */
/* CLASS_H-PM-FFSS21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 5    */
/* CLASS_H-PM-FFSS22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_U-PS-FFSF11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NF-MMLS31-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 2    */
/* CLASS_G-SF-SFMF32-M : protokoll_G-E--_006_K18_F1_PI_AE_S4_CS_SP_S0Y 14   */
/* CLASS_G-NF-MMLS32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_H-NM-FFMS21-M : protokoll_H----_047_K18_F1_PI_AE_S4_CS_SP_S2S 1    */
/* CLASS_U-NS-FFSF11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 3    */
/* CLASS_G-NF-MMLF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 2    */
/* CLASS_G-SF-SFMM00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 9    */
/* CLASS_G-NF-FFSF32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 8    */
/* CLASS_U-PF-FFSF22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 11   */
/* CLASS_H-SM-FFMF32-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 2    */
/* CLASS_U-PF-FFSF22-D : protokoll_G-E--_012_K18_F1_PI_AE_S4_CS_SP_S0Y 26   */
/* CLASS_G-SF-FFMF21-M : protokoll_G-E--_010_K07_F1_PI_AE_S4_CS_SP_S0Y 37   */
/* CLASS_H-SF-FFSS22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-SF-SSMM33-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 23   */
/* CLASS_G-NF-FFSM22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 4    */
/* CLASS_G-NF-SFMM33-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 3    */
/* CLASS_H-NF-FFSS00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 8    */
/* CLASS_G-NM-FFMM21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 5    */
/* CLASS_G-PF-MSMM21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 4    */
/* CLASS_G-SM-SFMM31-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_G-PF-FFSF11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 3    */
/* CLASS_G-SF-FFSF31-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-PM-FFMF21-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_U-PM-FFMM21-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_U-PF-FFSF21-D : protokoll_G-E--_012_K18_F1_PI_AE_S4_CS_SP_S0Y 135  */
/* CLASS_U-PF-FFSF32-M : protokoll_G-E--_006_K18_F1_PI_AE_S4_CS_SP_S0Y 5    */
/* CLASS_H-PF-FFSF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 1    */
/* CLASS_U-PF-FFSF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 27   */
/* CLASS_G-PF-FFSF00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_H-SF-SSMM33-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 14   */
/* CLASS_H-NM-MMLM00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 200  */
/* CLASS_H-NM-FFSF33-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-PF-SSMM22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 2    */
/* CLASS_G-SF-MMMM31-M : protokoll_H----_031_K18_F1_PI_AE_CS_SP_S3T 25   */
/* CLASS_G-SM-FFSF11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_H-PF-FFSS22-M : protokoll_H----_102_K18_F1_PI_AE_S4_CS_SP_S2S 1    */
/* CLASS_H-NF-FFSF21-D : protokoll_U----_043_K18_F2_PI_AE_CS_SP_S0Y 5    */
/* CLASS_G-NF-SMMS00-M : protokoll_G-E--_010_K07_F1_PI_AE_S4_CS_SP_S0Y 15   */
/* CLASS_U-NF-FFSF00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 16   */
/* CLASS_H-NF-FFSF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 3    */
/* CLASS_G-NF-MMLF11-M : protokoll_G-E--_010_K07_F1_PI_AE_S4_CS_SP_S0Y 1    */
/* CLASS_G-SF-FFMS22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 8    */
/* CLASS_G-NF-MMLF00-M : protokoll_G-E--_010_K07_F1_PI_AE_S4_CS_SP_S0Y 54   */
/* CLASS_G-SF-MMLM31-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_G-SM-SSMM21-M : protokoll_G-E--_003_K18_F1_AE_S4_CS_SP_S2S 78   */
/* CLASS_G-SF-SFMS32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S3S 14   */
/* CLASS_G-SF-MMLM31-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 1    */
/* CLASS_H-NS-FFMF21-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-SM-SSMM21-D : protokoll_G-E--_003_K18_F1_PI_AE_S4_CS_SP_S0Y 2    */
/* CLASS_H-NF-SFMS00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-NF-FFMM22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 4    */
/* CLASS_H-PS-FFSS22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_H-NF-FFMM32-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-SM-SSMM33-M : protokoll_H----_031_K18_F1_PI_AE_CS_SP_S3T 1    */
/* CLASS_H-NF-FFSF00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 28   */
/* CLASS_H-NF-FFSF22-M : protokoll_G-E--_044_K18_F1_PI_AE_S4_CS_OS_S1S 42   */
/* CLASS_H-NF-FFSF22-D : protokoll_G-E--_045_K18_F1_PI_AE_CS_SP_S00 15   */
/* CLASS_G-NM-FFMF31-M : protokoll_H----_047_K18_F1_PI_AE_S4_CS_SP_S2S 1    */
/* CLASS_G-NM-FFMF31-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NF-FFSM21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-SS-FFSM21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-SF-FFSF00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 6    */
/* CLASS_G-SM-SFMS33-M : protokoll_G-E--_044_K18_F1_PI_AE_S4_S1S 5    */
/* CLASS_G-NF-FFSF11-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NF-FFSF11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 61   */
/* CLASS_G-SM-SSLM31-D : protokoll_U----_043_K19_F1_PI_AE_CS_SP_S0Y 43   */
/* CLASS_G-NF-FFSF33-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-NF-FFMM00-M : protokoll_G-E--_011_K18_F1_PI_AE_S4_CS_SP_S0Y 21   */
/* CLASS_G-SM-FFMF22-M : protokoll_G-E--_012_K18_F1_PI_AE_S4_CS_SP_S0Y 7    */
/* CLASS_G-SS-SSMF32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 16   */
/* CLASS_G-SM-FFMF21-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_G-SS-FFSS21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_U-SM-FFMM21-D : protokoll_G-E--_045_B07_F1_PI_AE_S4_CS_SP_S0Y 2    */
/* CLASS_G-NF-FFMS00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 8    */
/* CLASS_G-SM-MMMM31-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 3    */
/* CLASS_U-PM-FFSF22-M : protokoll_G-E--_010_K07_F1_PI_AE_S4_CS_SP_S0Y 30   */
/* CLASS_G-NM-SSMM31-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-SF-FFMS21-M : protokoll_G-E--_007_K18_F1_PI_AE_S4_CS_SP_S0Y 32   */
/* CLASS_H-NM-FFMM31-D : protokoll_G-E--_010_B02_F1_PI_AE_S4_CS_SP_S0Y 1    */
/* CLASS_G-NS-SFMS00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NF-SFSM00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_H-NF-FFMM21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 30   */
/* CLASS_U-PM-FFSF22-D : protokoll_H----_081_B07_F1_PI_AE_S4_CS_SP_S2S 5    */
/* CLASS_G-SM-FFMS22-M : protokoll_H----_047_K18_F1_PI_AE_S4_CS_SP_S2S 1    */
/* CLASS_H-PS-FFSF22-M : protokoll_U----_043_K18_F2_PI_AE_CS_SP_S0Y 2    */
/* CLASS_H-PS-FFSF21-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_H-SM-FFMM22-M : protokoll_G-E--_045_K18_F1_PI_AE_S4_CS_SP_S2S 3    */
/* CLASS_H-PS-FFSF22-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_H-PS-FFSF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 4    */
/* CLASS_H-NF-SFMM11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 4    */
/* CLASS_G-NF-SFMM11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 9    */
/* CLASS_G-NF-SSMM11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 10   */
/* CLASS_H-SF-FFMM21-M : protokoll_H----_047_K18_F1_PI_AE_S4_CS_SP_S2S 1    */
/* CLASS_H-NS-FFMM32-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 12   */
/* CLASS_H-SM-FFSS21-M : protokoll_G-E--_011_K18_F1_PI_AE_S4_CS_SP_S0Y 4    */
/* CLASS_G-SS-FFSF22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 18   */
/* CLASS_G-NS-FFSF22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 3    */
/* CLASS_G-NF-SSMM32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_H-NS-FFMS11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-SS-SSMS32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_H-NM-FFMF31-M : protokoll_H----_047_K18_F1_PI_AE_S4_CS_SP_S2S 1    */
/* CLASS_G-SM-SFLM31-D : protokoll_G-E--_010_K07_F1_PI_AE_S4_CS_SP_S0Y 90   */
/* CLASS_G-NM-SSMM31-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-NF-SSMS32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_U-NM-FFSF22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-SF-SSMM31-M : protokoll_G-E--_007_K18_F1_PI_AE_S4_CS_SP_S0Y 7    */
/* CLASS_G-SF-SSMM31-D : protokoll_G-E--_012_K18_F1_PI_AE_S4_CS_SP_S0Y 3    */
/* CLASS_G-SF-SSMM32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 91   */
/* CLASS_H-NS-FFSF00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NF-SFMM32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 6    */
/* CLASS_G-NF-SFMS00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 3    */
/* CLASS_G-NM-FFMM32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_G-NS-FFSF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S3S 4    */
/* CLASS_G-NS-FFSF21-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_H-NF-FFMF32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-PF-MMLM21-M : protokoll_G-E--_044_K18_F1_PI_AE_S4_SP_S2S 21   */
/* CLASS_G-SM-MMLM22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_U-PF-FFSM22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_H-SS-FFSF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 15   */
/* CLASS_H-SF-FFSS21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 5    */
/* CLASS_G-NF-FFSM00-M : protokoll_H----_102_K18_F1_PI_AE_S4_CS_S1S 17   */
/* CLASS_G-SF-SMMM21-D : protokoll_G-E--_003_K18_F1_PI_AE_S4_CS_SP_S2S 5    */
/* CLASS_G-NF-FFSS11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 6    */
/* CLASS_H-NM-FFMS31-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_H-SS-FFSF22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 9    */
/* CLASS_G-SM-FFMS21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-PF-SFMF00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_H-SS-FFSF22-D : protokoll_G-E--_045_K18_F1_PI_AE_S4_CS_SP_S0Y 16   */
/* CLASS_H-NM-FFMS31-M : protokoll_G-E--_045_K18_F1_PI_AE_CS_SP_S00 3    */
/* CLASS_G-NM-FFMS31-D : protokoll_G-E--_008_K18_F1_PI_AE_S4_CS_SP_S0Y 3    */
/* CLASS_U-PS-FFSF21-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 19   */
/* CLASS_G-NS-FSMF11-M : protokoll_G-E--_045_K18_F1_PI_AE_S4_SP_S0Y 3    */
/* CLASS_U-PS-FFSF21-M : protokoll_U----_043_K19_F1_PI_AE_CS_SP_S0Y 43   */
/* CLASS_G-NS-SFMM00-M : protokoll_G-E--_045_K18_F1_PI_AE_S4_SP_S0Y 3    */
/* CLASS_G-SS-SSMS31-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_H-NS-FFSF31-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-SS-FFSF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 19   */
/* CLASS_G-NM-SSMM00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_U-NF-FFSM32-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NM-FFSF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 3    */
/* CLASS_G-PF-MMLM22-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-SF-SFMS31-M : protokoll_G-E--_003_K18_F1_AE_S4_CS_SP_S0Y 6    */
/* CLASS_G-SF-SSMF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_G-SM-MSMS32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_G-PF-MMLM22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 16   */
/* CLASS_H-NM-FFMM00-M : protokoll_G-E--_045_K18_F1_PI_AE_S4_CS_SP_S0Y 2    */
/* CLASS_U-PF-FFSM21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_H-NM-SFMM21-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 4    */
/* CLASS_H-NM-SSMF22-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 3    */
/* CLASS_H-PF-FFSF22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_U-NS-FFSF22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 4    */
/* CLASS_G-NF-SSMF11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 12   */
/* CLASS_U-PF-FFSS22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_U-PS-FFSF22-M : protokoll_G-E--_045_K18_F1_PI_AE_S4_CS_SP_S0Y 55   */
/* CLASS_G-SM-MMLM21-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_G-SF-FFMM31-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_U-PS-FFSF22-D : protokoll_G-E--_012_K18_F1_PI_AE_S4_CS_SP_S0Y 98   */
/* CLASS_U-SM-SFMM21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-SM-MMLM21-M : protokoll_G-E--_003_K18_F1_PI_AE_S4_CS_SP_S0Y 2    */
/* CLASS_G-SM-FFMF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 4    */
/* CLASS_H-SM-SFMM21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NS-FFSS00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-NF-SFMF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NF-MMLM31-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 4    */
/* CLASS_G-SF-MMLS31-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-NS-FFMF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 5    */
/* CLASS_G-NF-SSMM11-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_G-NS-FFMM21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NS-FFMF21-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-SM-FFSS21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 8    */
/* CLASS_U-SM-SFMM22-M : protokoll_G-E--_010_K18_F2_PI_AE_S4_CS_SP_S0Y 1    */
/* CLASS_G-NF-FFMF22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 3    */
/* CLASS_G-NF-FFMF21-M : protokoll_H----_014_K18_F1_PI_AE_CS_SP_S2S 18   */
/* CLASS_G-SM-MSMM32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_G-SM-SSMF31-M : protokoll_G-E--_003_K18_F1_PI_AE_S4_CS_SP_S2S 1    */
/* CLASS_H-NS-FFSF22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 10   */
/* CLASS_G-SM-SFMS21-D : protokoll_G-E--_010_K18_F1_PI_AE_CS_SP_S0Y 18   */
/* CLASS_G-SF-FFMM32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_U-PF-FFSF00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 19   */
/* CLASS_G-NF-FFMF00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 5    */
/* CLASS_H-PM-FFMM21-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_H-NF-FFMF21-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 5    */
/* CLASS_U-PS-FFSS21-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_H-NF-FFMF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 2    */
/* CLASS_G-SM-SSMS33-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 3    */
/* CLASS_G-SF-FFSM11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-NF-FFSS32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-PF-SFMM21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 23   */
/* CLASS_G-SM-SSMS31-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 23   */
/* CLASS_G-NF-FFMM21-M : protokoll_H----_102_B31_F1_PI_AE_S4_CS_SP_S2S 59   */
/* CLASS_H-NM-FFMF33-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_G-NF-MMLM32-M : protokoll_H----_102_B31_F1_PI_AE_S4_CS_SP_S2S 17   */
/* CLASS_H-NS-FFSF33-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NM-SFMM31-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_H-NM-SFMM22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_H-NM-FFSS11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-NM-FFMS11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NM-SFMM31-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-SS-FFMS33-M : protokoll_G-E--_003_K18_F1_AE_S4_CS_SP_S0Y 6    */
/* CLASS_G-NS-FFMS21-D : protokoll_G-E--_045_K18_F1_PI_AE_S4_CS_SP_S0Y 10   */
/* CLASS_G-SF-FFSF22-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_H-NS-FFSS11-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NS-FFMS21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 3    */
/* CLASS_G-SF-FFSF22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 12   */
/* CLASS_G-SF-FFSF11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 5    */
/* CLASS_H-SF-SSMM00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-PF-SSLM22-M : protokoll_H----_047_K18_F1_PI_AE_S4_CS_SP_S2S 4    */
/* CLASS_G-NF-MMLS00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_U-PM-FFSS21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_H-SM-FFSF32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 1    */
/* CLASS_G-NM-FFMF32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 5    */
/* CLASS_G-SF-SFMM33-M : protokoll_G-E--_010_K18_F1_PI_AE_CS_SP_S0Y 1    */
/* CLASS_H-SF-FFSS32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_H-SF-FFSF22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_H-SF-FFSF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 15   */
/* CLASS_G-NF-SSMM00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S3S 28   */
/* CLASS_U-NF-FFSF11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 10   */
/* CLASS_G-SM-SMMM31-M : protokoll_U----_043_K18_F2_PI_AE_CS_SP_S0Y 32   */
/* CLASS_G-SM-FFSF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 3    */
/* CLASS_G-SF-SMLM33-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 20   */
/* CLASS_G-SM-FFSF21-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_G-SF-MMLM00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 9    */
/* CLASS_G-NM-FFMS32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_H-NF-FFSS32-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-SM-FFSF22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_H-NF-FFSM00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 3    */
/* CLASS_U-PM-FFSS22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_H-NM-FFMM21-D : protokoll_G-E--_010_B02_F1_PI_AE_S4_CS_SP_S0Y 6    */
/* CLASS_G-NF-SSMF32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_H-NM-FFMM21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NF-SMMM00-M : protokoll_G-E--_010_K07_F1_PI_AE_S4_CS_SP_S0Y 82   */
/* CLASS_G-SM-SFMM21-D : protokoll_G-E--_007_K18_F1_PI_AE_S4_CS_SP_S0Y 21   */
/* CLASS_G-SF-FFMM33-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 2    */
/* CLASS_H-NF-FFSM22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 12   */
/* CLASS_G-SF-FFMF11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-NM-FFMF22-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NF-SSMM22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 6    */
/* CLASS_H-SS-FFSS22-M : protokoll_G-E--_045_K18_F1_PI_AE_S4_CS_SP_S0Y 6    */
/* CLASS_G-SM-SSMS32-M : protokoll_H----_024_K18_F1_PI_OP_AE_S4_CS_SP_S2S 3    */
/* CLASS_G-NF-MMLM11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_H-NF-FFSM21-M : protokoll_H----_047_K18_F1_PI_AE_S4_CS_SP_S2S 3    */
/* CLASS_G-SF-MMMM21-D : protokoll_G-E--_003_K18_F1_PI_AE_S4_CS_SP_S2S 10   */
/* CLASS_G-NF-SFMF00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 12   */
/* CLASS_U-PM-FFMS21-M : protokoll_G-E--_006_K18_F1_PI_AE_S4_CS_SP_S0Y 6    */
/* CLASS_H-SM-FFMS21-M : protokoll_G-E--_044_K18_F1_PI_AE_S4_SP_S2S 11   */
/* CLASS_G-SM-SSMS31-D : protokoll_G-E--_007_K18_F1_PI_AE_S4_CS_SP_S0Y 3    */
/* CLASS_G-SF-MMMM21-M : protokoll_G-E--_008_K18_F1_PI_AE_S4_CS_SP_S0Y 54   */
/* CLASS_U-NF-FFSF22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_H-NF-SFMF11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 4    */
/* CLASS_G-NF-FFSF00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 71   */
/* CLASS_U-NF-FFSF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 3    */
/* CLASS_G-NF-SFSS00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_H-SM-FFMF21-M : protokoll_G-E--_001_K18_F1_PI_AE_S4_CS_SP_S2S 40   */
/* CLASS_H-NS-FFMS21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NF-MMLM33-M : protokoll_H----_042_B07_F1_PI_AE_SP_S2S 45   */
/* CLASS_H-SM-FFMF21-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_H-SM-FFMF22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_H-SS-FFSS21-M : protokoll_G-E--_007_K18_F1_PI_AE_S4_CS_SP_S0Y 6    */
/* CLASS_G-SF-SFMF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_H-NS-FFMS22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 1    */
/* CLASS_H-NF-FFMF00-M : protokoll_G-E--_045_K18_F1_PI_AE_CS_SP_S00 4    */
/* CLASS_G-PM-FFSS22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-SF-FFMS32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-NF-SMLF00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 36   */
/* CLASS_G-SM-SSMF33-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 12   */
/* CLASS_U-PM-FFMF22-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NF-FFSF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 19   */
/* CLASS_U-PM-FFMF21-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 14   */
/* CLASS_G-NF-FFSF21-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_U-PM-FFMF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 15   */
/* CLASS_H-SF-SFMS11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-SF-FFMF32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_H-SF-SSMM22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_H-SM-FFMM31-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_H-SF-SFMM22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 22   */
/* CLASS_G-SS-FFMF33-M : protokoll_H----_047_K18_F1_PI_AE_S4_CS_SP_S2S 47   */
/* CLASS_G-NF-FFMM33-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NF-SMMF11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 4    */
/* CLASS_H-SF-FFMS32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NM-FFMF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 7    */
/* CLASS_H-NF-FFMM22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 6    */
/* CLASS_G-PS-SFMM21-M : protokoll_H----_102_K18_F1_PI_AE_S4_CS_SP_S2S 55   */
/* CLASS_G-NM-FFMF21-D : protokoll_G-E--_045_K18_F1_PI_AE_S4_CS_SP_S0Y 4    */
/* CLASS_G-SF-MMLM21-M : protokoll_G-E--_003_K18_F1_PI_AE_S4_CS_SP_S2S 4    */
/* CLASS_G-SF-SFMS21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 6    */
/* CLASS_G-SF-MMLM21-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_G-SF-MMLM22-M : protokoll_G-E--_011_K18_F1_PI_AE_S4_CS_SP_S0Y 14   */
/* CLASS_G-NF-FFSF22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 41   */
/* CLASS_G-SF-FFMF31-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 6    */
/* CLASS_G-PF-FFMF11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_H-SM-FFMS22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NF-MMMM00-M : protokoll_G-E--_011_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 16   */
/* CLASS_H-NM-SFMS22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_U-PM-FFMF32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_G-SM-FFMM31-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-SF-SSLS33-M : protokoll_H----_031_K18_F1_PI_AE_CS_SP_S3T 4    */
/* CLASS_G-NM-SSMM22-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 2    */
/* CLASS_U-PF-FFSF11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-NF-FFMF33-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-NF-FFSM11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_H-NM-FFMF22-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 3    */
/* CLASS_G-SM-FFMF33-M : protokoll_G-E--_001_K18_F1_PI_AE_S4_CS_SP_S2S 21   */
/* CLASS_H-NM-FFSF21-M : protokoll_U----_043_K18_F2_PI_AE_CS_SP_S0Y 83   */
/* CLASS_G-NF-SFMS11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-SM-SSMM32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_H-NM-FFMF21-D : protokoll_H----_024_K18_F1_PI_OP_AE_S4_CS_SP_S2S 2    */
/* CLASS_H-NF-FFSF11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 15   */
/* CLASS_H-NM-FFMF21-M : protokoll_H----_102_K18_F1_PI_AE_S4_CS_SP_S2S 8    */
/* CLASS_H-NF-FFSF11-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 2    */
/* CLASS_G-SM-FFMM32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_G-NS-FFMS00-M : protokoll_H----_102_K18_F1_PI_AE_S4_CS_S1S 4    */
/* CLASS_H-NM-SFMF33-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 3    */
/* CLASS_H-PM-FFSM22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 1    */
/* CLASS_G-SM-MMMM21-M : protokoll_G-E--_007_K18_F1_PI_AE_S4_CS_SP_S0Y 25   */
/* CLASS_G-NF-SSMS11-M : protokoll_H----_031_K18_F1_PI_AE_CS_SP_S3T 2    */
/* CLASS_G-SM-MMMM21-D : protokoll_G-E--_008_K18_F1_PI_AE_S4_CS_SP_S0Y 5    */
/* CLASS_G-SM-SSMM31-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-NF-FFMM31-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 4    */
/* CLASS_G-SM-SSMM31-D : protokoll_H----_047_K18_F1_PI_AE_S4_CS_SP_S2S 13   */
/* CLASS_H-SF-SFMM11-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 6    */
/* CLASS_G-SF-SFMM31-M : protokoll_H----_024_K18_F1_PI_AE_S4_CS_SP_S2S 6    */
/* CLASS_U-PM-FFSF21-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 8    */
/* CLASS_G-NM-SFMS22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-SF-FFSS22-M : protokoll_G-E--_045_K18_F1_PI_AE_S4_CS_SP_S0Y 1    */
/* CLASS_U-PM-FFSF21-M : protokoll_H----_011_K07_F1_PI_AE_OS_S1U 176  */
/* CLASS_G-NM-SFMS22-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_H-NS-FFSF22-D : protokoll_U----_043_K18_F2_PI_AE_CS_SP_S0Y 7    */
/* CLASS_G-NF-SFMM22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 4    */
/* CLASS_G-SF-SSMM21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 2    */
/* CLASS_G-NF-SFMM21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 4    */
/* CLASS_G-SF-SSMS31-D : protokoll_G-E--_010_K07_F1_PI_AE_S4_CS_SP_S0Y 12   */
/* CLASS_H-NM-SFMM31-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */
/* CLASS_G-SF-SSMS31-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 8    */
/* CLASS_G-NF-SFMS32-M : protokoll_H----_102_B03_F1_PI_AE_S4_CS_SP_S2S 1    */
/* CLASS_G-SS-FFMM33-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_H-SS-FFSM22-M : protokoll_H----_102_K18_F1_PI_AE_S4_CS_SP_S2S 2    */
/* CLASS_G-SF-MMLF33-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 0    */
/* CLASS_G-PS-FFMM21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 129  */
/* CLASS_H-SF-FFMM32-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 1    */
/* CLASS_G-NF-FFMM32-M : protokoll_G-E--_006_K18_F1_PI_AE_S4_CS_SP_S0Y 3    */
/* CLASS_H-NS-FFMM21-D : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_G-NF-SSMS00-M : protokoll_G-E--_044_K18_F1_PI_AE_S4_S1S 11   */
/* CLASS_H-NM-FFSF22-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S2S_backup 7    */
/* CLASS_H-NM-FFSF21-D : protokoll_H----_072_K16_F1_PI_AE_CS_S4_S0Y 122  */
/* CLASS_U-NF-FFSM00-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 2    */
/* CLASS_H-NM-FFSF22-D : protokoll_U----_043_B07_F1_PI_AE_CS_SP_S0Y 2    */
/* CLASS_G-SS-SSMF21-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 7    */
/* CLASS_G-SM-SFMF33-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 17   */
/* CLASS_G-SF-FFMF33-M : protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup 1    */

#ifdef CHE_PROOFCONTROL_INTERNAL

/* Strategies used:                                       */


"H_____011_K07_F1_PI_AE_OS_S1U = \n"
"(8*Refinedweight(PreferGoals,1,2,2,1,0.8),"
" 8*Refinedweight(PreferNonGoals,2,1,2,3,0.8),"
" 1*Clauseweight(ConstPrio,1,1,0.7),"
" 1*FIFOWeight(ByNegLitDist))\n"
"G_E___003_K18_F1_AE_S4_CS_SP_S2S = \n"
"(10*ConjectureRelativeSymbolWeight(ConstPrio,0.2, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____042_B07_F1_PI_AE_SP_S2S = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 5*OrientLMaxWeight(ConstPrio,2,1,2,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____047_K18_F1_PI_AE_S4_CS_SP_S2S = \n"
"(10*PNRefinedweight(PreferGoals,1,1,1,2,2,2,0.5),"
" 10*PNRefinedweight(PreferNonGoals,2,1,1,1,2,2,2),"
" 5*OrientLMaxWeight(ConstPrio,2,1,2,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"G_E___012_K18_F1_PI_AE_S4_CS_SP_S0Y = \n"
"(7*ConjectureRelativeSymbolWeight(ConstPrio,0.5, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 3*OrientLMaxWeight(ConstPrio,2,1,2,1,1),"
" 1*FIFOWeight(PreferProcessed))\n"
"U_____043_B07_F1_PI_AE_CS_SP_S0Y = \n"
"(4*PNRefinedweight(PreferNonGoals,4,5,5,4,2,1,1),"
" 8*PNRefinedweight(PreferGoals,5,2,2,5,2,1,0.5),"
" 1*FIFOWeight(ConstPrio))\n"
"G_E___045_K18_F1_PI_AE_CS_SP_S00 = \n"
"(4*Refinedweight(SimulateSOS,1,1,2,1.5,2),"
" 3*Refinedweight(PreferNonGoals,1,1,2,1.5,1.5),"
" 1*Clauseweight(PreferProcessed,1,1,1),"
" 1*FIFOWeight(PreferProcessed))\n"
"G_E___010_K18_F1_PI_AE_S4_CS_SP_S2S = \n"
"(4*ConjectureRelativeSymbolWeight(SimulateSOS,0.5, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 3*ConjectureRelativeSymbolWeight(PreferNonGoals,0.5, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 1*Clauseweight(PreferProcessed,1,1,1),"
" 1*FIFOWeight(PreferProcessed))\n"
"G_E___045_K18_F1_PI_AE_S4_SP_S0Y = \n"
"(4*Refinedweight(SimulateSOS,1,1,2,1.5,2),"
" 3*Refinedweight(PreferNonGoals,1,1,2,1.5,1.5),"
" 1*Clauseweight(PreferProcessed,1,1,1),"
" 1*FIFOWeight(PreferProcessed))\n"
"H_____014_K18_F1_PI_AE_CS_SP_S2S = \n"
"(12*Refinedweight(PreferGoals,1,2,2,1,0.8),"
" 12*Refinedweight(PreferNonGoals,2,1,2,3,0.8),"
" 2*ClauseWeightAge(ConstPrio,1,1,0.7,3))\n"
"G_E___011_K18_F1_PI_AE_S4_CS_SP_S0Y = \n"
"(7*ConjectureRelativeSymbolWeight(ConstPrio,0.5, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 1*Clauseweight(PreferProcessed,1,1,1),"
" 1*FIFOWeight(PreferProcessed))\n"
"G_E___045_B07_F1_PI_AE_S4_CS_SP_S0Y = \n"
"(4*Refinedweight(SimulateSOS,1,1,2,1.5,2),"
" 3*Refinedweight(PreferNonGoals,1,1,2,1.5,1.5),"
" 1*Clauseweight(PreferProcessed,1,1,1),"
" 1*FIFOWeight(PreferProcessed))\n"
"G_E___008_K18_F1_PI_AE_S4_CS_SP_S0Y = \n"
"(10*ConjectureRelativeSymbolWeight(ConstPrio,0.1, 100, 100, 100, 100, 1.5, 1.5, 1.5),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____081_B02_F1_PI_AE_S4_CS_SP_S2S = \n"
"(8*Refinedweight(PreferGoals,1,2,2,2,2),"
" 8*Refinedweight(PreferNonGoals,2,1,2,2,0.5),"
" 1*Clauseweight(PreferUnitGroundGoals,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____081_B07_F1_PI_AE_S4_CS_SP_S2S = \n"
"(8*Refinedweight(PreferGoals,1,2,2,2,2),"
" 8*Refinedweight(PreferNonGoals,2,1,2,2,0.5),"
" 1*Clauseweight(PreferUnitGroundGoals,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____024_K18_F1_PI_OP_AE_S4_CS_SP_S2S = \n"
"(12*SymbolTypeweight(ConstPrio,7,20,0,0,1.5,5,0.8),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____024_K18_F1_PI_AE_S4_CS_SP_S2S = \n"
"(12*SymbolTypeweight(ConstPrio,7,20,0,0,1.5,5,0.8),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____081_K18_F1_PI_AE_S4_CS_SP_S2S = \n"
"(8*Refinedweight(PreferGoals,1,2,2,2,2),"
" 8*Refinedweight(PreferNonGoals,2,1,2,2,0.5),"
" 1*Clauseweight(PreferUnitGroundGoals,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"G_E___010_K07_F1_PI_AE_S4_CS_SP_S0Y = \n"
"(4*ConjectureRelativeSymbolWeight(SimulateSOS,0.5, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 3*ConjectureRelativeSymbolWeight(PreferNonGoals,0.5, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 1*Clauseweight(PreferProcessed,1,1,1),"
" 1*FIFOWeight(PreferProcessed))\n"
"H_____072_K16_F1_PI_AE_CS_S4_S0Y = \n"
"(10*Refinedweight(PreferGroundGoals,2,1,2,1.0,1),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*Clauseweight(ByCreationDate,2,1,0.8))\n"
"G_E___044_K18_F1_PI_AE_S4_CS_SP_S2S = \n"
"(4*Refinedweight(SimulateSOS,1,1,2,1.5,2),"
" 3*Refinedweight(PreferNonGoals,1,1,2,1.5,1.5),"
" 2*Clauseweight(PreferProcessed,1,1,1),"
" 1*FIFOWeight(PreferProcessed))\n"
"G_E___001_K18_F1_PI_AE_S4_CS_SP_S2S = \n"
"(10*ConjectureSymbolWeight(ConstPrio,10,10,5,5,5,1.5,1.5,1.5),"
" 1*FIFOWeight(ConstPrio))\n"
"U_____043_K09_F1_PI_AE_CS_SP_S0Y = \n"
"(4*PNRefinedweight(PreferNonGoals,4,5,5,4,2,1,1),"
" 8*PNRefinedweight(PreferGoals,5,2,2,5,2,1,0.5),"
" 1*FIFOWeight(ConstPrio))\n"
"G_E___044_K18_F1_PI_AE_S4_CS_OS_S1S = \n"
"(4*Refinedweight(SimulateSOS,1,1,2,1.5,2),"
" 3*Refinedweight(PreferNonGoals,1,1,2,1.5,1.5),"
" 2*Clauseweight(PreferProcessed,1,1,1),"
" 1*FIFOWeight(PreferProcessed))\n"
"H_____011_K07_F1_PI_AE_S4_CS_SP_SOV = \n"
"(8*Refinedweight(PreferGoals,1,2,2,1,0.8),"
" 8*Refinedweight(PreferNonGoals,2,1,2,3,0.8),"
" 1*Clauseweight(ConstPrio,1,1,0.7),"
" 1*FIFOWeight(ByNegLitDist))\n"
"U_____043_K18_F2_PI_AE_CS_SP_S0Y = \n"
"(4*PNRefinedweight(PreferNonGoals,4,5,5,4,2,1,1),"
" 8*PNRefinedweight(PreferGoals,5,2,2,5,2,1,0.5),"
" 1*FIFOWeight(ConstPrio))\n"
"G_E___045_K18_F1_PI_AE_S4_CS_SP_S0Y = \n"
"(4*Refinedweight(SimulateSOS,1,1,2,1.5,2),"
" 3*Refinedweight(PreferNonGoals,1,1,2,1.5,1.5),"
" 1*Clauseweight(PreferProcessed,1,1,1),"
" 1*FIFOWeight(PreferProcessed))\n"
"G_E___010_K18_F1_PI_AE_S4_CS_SP_S3S = \n"
"(4*ConjectureRelativeSymbolWeight(SimulateSOS,0.5, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 3*ConjectureRelativeSymbolWeight(PreferNonGoals,0.5, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 1*Clauseweight(PreferProcessed,1,1,1),"
" 1*FIFOWeight(PreferProcessed))\n"
"G_E___010_B02_F1_PI_AE_S4_CS_SP_S0Y = \n"
"(4*ConjectureRelativeSymbolWeight(SimulateSOS,0.5, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 3*ConjectureRelativeSymbolWeight(PreferNonGoals,0.5, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 1*Clauseweight(PreferProcessed,1,1,1),"
" 1*FIFOWeight(PreferProcessed))\n"
"G_E___003_K18_F1_PI_AE_S4_CS_SP_S0Y = \n"
"(10*ConjectureRelativeSymbolWeight(ConstPrio,0.2, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 1*FIFOWeight(ConstPrio))\n"
"U_____043_K19_F1_PI_AE_CS_SP_S0Y = \n"
"(4*PNRefinedweight(PreferNonGoals,4,5,5,4,2,1,1),"
" 8*PNRefinedweight(PreferGoals,5,2,2,5,2,1,0.5),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____042_B30_F1_PI_AE_SP_S2S = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 5*OrientLMaxWeight(ConstPrio,2,1,2,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"G_E___003_K18_F1_PI_AE_S4_CS_OS_S0Y_backup = \n"
"(10*ConjectureRelativeSymbolWeight(ConstPrio,0.2, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 1*FIFOWeight(ConstPrio))\n"
"G_E___007_K18_F1_PI_AE_S4_CS_SP_S0Y = \n"
"(10*ConjectureRelativeSymbolWeight(ConstPrio,0.2, 100, 100, 100, 100, 1.5, 1.5, 1.5),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____011_K07_F1_PI_AE_SP_SOV = \n"
"(8*Refinedweight(PreferGoals,1,2,2,1,0.8),"
" 8*Refinedweight(PreferNonGoals,2,1,2,3,0.8),"
" 1*Clauseweight(ConstPrio,1,1,0.7),"
" 1*FIFOWeight(ByNegLitDist))\n"
"G_E___010_K18_F2_PI_AE_S4_CS_SP_S0Y = \n"
"(4*ConjectureRelativeSymbolWeight(SimulateSOS,0.5, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 3*ConjectureRelativeSymbolWeight(PreferNonGoals,0.5, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 1*Clauseweight(PreferProcessed,1,1,1),"
" 1*FIFOWeight(PreferProcessed))\n"
"G_E___003_K18_F1_PI_AE_S4_CS_SP_S2S = \n"
"(10*ConjectureRelativeSymbolWeight(ConstPrio,0.2, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____102_K18_F1_PI_AE_S4_CS_S1S = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 3*OrientLMaxWeight(ConstPrio,2,1,2,1,1),"
" 2*ClauseWeightAge(ConstPrio,1,1,1,3))\n"
"G_E___010_K18_F1_PI_AE_S4_CS_SP_S2S_backup = \n"
"(4*ConjectureRelativeSymbolWeight(SimulateSOS,0.5, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 3*ConjectureRelativeSymbolWeight(PreferNonGoals,0.5, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 1*Clauseweight(PreferProcessed,1,1,1),"
" 1*FIFOWeight(PreferProcessed))\n"
"G_E___045_K18_F1_PI_AE_S4_CS_SP_S2S = \n"
"(4*Refinedweight(SimulateSOS,1,1,2,1.5,2),"
" 3*Refinedweight(PreferNonGoals,1,1,2,1.5,1.5),"
" 1*Clauseweight(PreferProcessed,1,1,1),"
" 1*FIFOWeight(PreferProcessed))\n"
"H_____031_K09_F1_PI_AE_SP_S0Y = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____042_B03_F1_PI_AE_SP_S2S = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 5*OrientLMaxWeight(ConstPrio,2,1,2,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"G_E___011_K18_F1_PI_AE_S4_CS_SP_S0Y_backup = \n"
"(7*ConjectureRelativeSymbolWeight(ConstPrio,0.5, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 1*Clauseweight(PreferProcessed,1,1,1),"
" 1*FIFOWeight(PreferProcessed))\n"
"G_E___010_K18_F1_PI_AE_CS_SP_S0Y = \n"
"(4*ConjectureRelativeSymbolWeight(SimulateSOS,0.5, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 3*ConjectureRelativeSymbolWeight(PreferNonGoals,0.5, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 1*Clauseweight(PreferProcessed,1,1,1),"
" 1*FIFOWeight(PreferProcessed))\n"
"G_E___044_K18_F1_PI_AE_S4_SP_S2S = \n"
"(4*Refinedweight(SimulateSOS,1,1,2,1.5,2),"
" 3*Refinedweight(PreferNonGoals,1,1,2,1.5,1.5),"
" 2*Clauseweight(PreferProcessed,1,1,1),"
" 1*FIFOWeight(PreferProcessed))\n"
"H_____031_K18_F1_PI_AE_CS_SP_S3T = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 1*Clauseweight(ConstPrio,1,1,1),"
" 1*FIFOWeight(ConstPrio))\n"
"G_E___003_K18_F1_AE_S4_CS_SP_S0Y = \n"
"(10*ConjectureRelativeSymbolWeight(ConstPrio,0.2, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 1*FIFOWeight(ConstPrio))\n"
"G_E___044_K18_F1_PI_AE_S4_S1S = \n"
"(4*Refinedweight(SimulateSOS,1,1,2,1.5,2),"
" 3*Refinedweight(PreferNonGoals,1,1,2,1.5,1.5),"
" 2*Clauseweight(PreferProcessed,1,1,1),"
" 1*FIFOWeight(PreferProcessed))\n"
"G_E___010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup = \n"
"(4*ConjectureRelativeSymbolWeight(SimulateSOS,0.5, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 3*ConjectureRelativeSymbolWeight(PreferNonGoals,0.5, 100, 100, 100, 100, 1.5, 1.5, 1),"
" 1*Clauseweight(PreferProcessed,1,1,1),"
" 1*FIFOWeight(PreferProcessed))\n"
"H_____036_K18_F2_PI_AE_S4_SP_S2S = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 2*ClauseWeightAge(ConstPrio,1,1,1,3))\n"
"G_E___006_K18_F1_PI_AE_S4_CS_SP_S0Y = \n"
"(10*ConjectureRelativeSymbolWeight(ConstPrio,0.5, 100, 100, 100, 50, 1.5, 1.5, 1.5),"
" 1*FIFOWeight(ConstPrio))\n"
"H_____102_B03_F1_PI_AE_S4_CS_SP_S2S = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 3*OrientLMaxWeight(ConstPrio,2,1,2,1,1),"
" 2*ClauseWeightAge(ConstPrio,1,1,1,3))\n"
"H_____102_B31_F1_PI_AE_S4_CS_SP_S2S = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 3*OrientLMaxWeight(ConstPrio,2,1,2,1,1),"
" 2*ClauseWeightAge(ConstPrio,1,1,1,3))\n"
"H_____102_K18_F1_PI_AE_S4_CS_SP_S2S = \n"
"(10*Refinedweight(PreferGoals,1,2,2,2,0.5),"
" 10*Refinedweight(PreferNonGoals,2,1,2,2,2),"
" 3*OrientLMaxWeight(ConstPrio,2,1,2,1,1),"
" 2*ClauseWeightAge(ConstPrio,1,1,1,3))\n"
/* Global best, protokoll_G-E--_010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup, already defined */
#endif

#if defined(CHE_HEURISTICS_INTERNAL) || defined(TO_ORDERING_INTERNAL)

   else if(
      ( /* CLASS_U-PM-FFSF21-M Solved: 176 of 204 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____011_K07_F1_PI_AE_OS_S1U";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectComplexAHPExceptRRHorn;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodOrientedSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_G-SM-SSMM21-M Solved: 78 of 95 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___003_K18_F1_AE_S4_CS_SP_S2S";
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectNewComplexAHP;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-SF-SFMF31-M Solved: 5 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-MMLM33-M Solved: 45 of 52 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____042_B07_F1_PI_AE_SP_S2S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplexAHP;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=LPO4;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_H-PM-FFSF21-D Solved: 1 of 6 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-PM-FFSF21-M Solved: 6 of 10 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-PM-FFMF21-D Solved: 2 of 7 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMS21-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMF31-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMS22-M Solved: 1 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFMM21-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMF31-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-SSLM22-M Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSM21-M Solved: 3 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMF33-M Solved: 47 of 77 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SSMM31-D Solved: 13 of 14 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____047_K18_F1_PI_AE_S4_CS_SP_S2S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectNewComplexAHP;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_H-SM-FFSF21-M Solved: 22 of 29 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMF22-M Solved: 14 of 21 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PF-FFSF22-D Solved: 26 of 36 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_U-PF-FFSF21-D Solved: 135 of 142 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMF22-M Solved: 7 of 10 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SSMM31-D Solved: 3 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_U-PS-FFSF22-D Solved: 98 of 106 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___012_K18_F1_PI_AE_S4_CS_SP_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_H-NM-FFSF22-D Solved: 2 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "U_____043_B07_F1_PI_AE_CS_SP_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=LPO4;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_H-NF-FFSF22-D Solved: 15 of 22 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMS31-M Solved: 3 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFMF00-M Solved: 4 of 6 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___045_K18_F1_PI_AE_CS_SP_S00";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectNoLiterals;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-SF-SMMM21-M Solved: 202 of 290 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___010_K18_F1_PI_AE_S4_CS_SP_S2S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectNewComplexAHP;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-NF-FFMF11-M Solved: 25 of 26 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SFMM33-M Solved: 1 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFMF11-M Solved: 4 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FSMF11-M Solved: 3 of 20 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-SFMM00-M Solved: 3 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___045_K18_F1_PI_AE_S4_SP_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-NF-FFMF21-M Solved: 18 of 20 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____014_K18_F1_PI_AE_CS_SP_S2S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectNewComplexAHP;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-NF-FFMM00-M Solved: 21 of 25 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFSS21-M Solved: 4 of 4 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-MMLM22-M Solved: 14 of 26 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___011_K18_F1_PI_AE_S4_CS_SP_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-PM-FFSF22-M Solved: 1 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-SM-FFMM21-D Solved: 2 of 2 */
       SpecAxiomsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___045_B07_F1_PI_AE_S4_CS_SP_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=LPO4;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_G-NM-FFMS31-D Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-MMMM21-M Solved: 54 of 66 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-MMMM21-D Solved: 5 of 9 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___008_K18_F1_PI_AE_S4_CS_SP_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-SF-FFSF21-M Solved: 18 of 18 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____081_B02_F1_PI_AE_S4_CS_SP_S2S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectNewComplex;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=LPO4;
      oparms.to_prec_gen=PArity;

#endif
   }
   else if(
      ( /* CLASS_U-PM-FFSF22-D Solved: 5 of 6 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____081_B07_F1_PI_AE_S4_CS_SP_S2S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectNewComplex;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=LPO4;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_G-SF-SFMM21-M Solved: 10 of 10 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SSMS32-M Solved: 3 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMF21-D Solved: 2 of 4 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____024_K18_F1_PI_OP_AE_S4_CS_SP_S2S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectNewComplexAHP;
      control->heuristic_parms.select_on_proc_only=true;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-SF-SFMM31-M Solved: 6 of 10 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____024_K18_F1_PI_AE_S4_CS_SP_S2S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectNewComplexAHP;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_H-NM-FFMS21-D Solved: 3 of 6 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____081_K18_F1_PI_AE_S4_CS_SP_S2S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectNewComplex;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-SF-FFMF21-M Solved: 37 of 60 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SMMS00-M Solved: 15 of 15 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-MMLF11-M Solved: 1 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-MMLF00-M Solved: 54 of 56 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFSF22-M Solved: 30 of 36 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SFLM31-D Solved: 90 of 437 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SMMM00-M Solved: 82 of 98 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SSMS31-D Solved: 12 of 39 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___010_K07_F1_PI_AE_S4_CS_SP_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_H-NM-FFSF21-D Solved: 122 of 201 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____072_K16_F1_PI_AE_CS_S4_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WPrecedence;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-SM-SMMM21-M Solved: 168 of 233 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___044_K18_F1_PI_AE_S4_CS_SP_S2S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectNewComplexAHP;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-SS-MMLM22-M Solved: 11 of 22 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-MSLM21-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFMF21-M Solved: 40 of 43 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMF33-M Solved: 21 of 21 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___001_K18_F1_PI_AE_S4_CS_SP_S2S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectNewComplexAHP;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-NS-SSMF11-M Solved: 6 of 15 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "U_____043_K09_F1_PI_AE_CS_SP_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WAritySqWeight;
      oparms.to_prec_gen=PArity;

#endif
   }
   else if(
      ( /* CLASS_H-NF-FFSF22-M Solved: 42 of 47 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___044_K18_F1_PI_AE_S4_CS_OS_S1S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectComplexAHP;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodOrientedSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_H-NS-FFSF21-M Solved: 87 of 92 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____011_K07_F1_PI_AE_S4_CS_SP_SOV";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=PSelectComplexExceptRRHorn;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_H-NF-FFSF21-D Solved: 5 of 9 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-PS-FFSF22-M Solved: 2 of 4 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SMMM31-M Solved: 32 of 32 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFSF21-M Solved: 83 of 94 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSF22-D Solved: 7 of 13 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "U_____043_K18_F2_PI_AE_CS_SP_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=2;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_H-NS-FFSF11-M Solved: 5 of 5 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMS21-D Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-SS-FFSF22-D Solved: 16 of 18 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMM00-M Solved: 2 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PS-FFSF22-M Solved: 55 of 58 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFMS21-D Solved: 10 of 10 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-SS-FFSS22-M Solved: 6 of 6 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMF21-D Solved: 4 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSS22-M Solved: 1 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___045_K18_F1_PI_AE_S4_CS_SP_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-SF-SFMS32-M Solved: 14 of 32 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFSF21-M Solved: 4 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SSMM00-M Solved: 28 of 30 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___010_K18_F1_PI_AE_S4_CS_SP_S3S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectNewComplexAHPExceptUniqMaxHorn;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_H-NM-FFMM31-D Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMM21-D Solved: 6 of 6 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___010_B02_F1_PI_AE_S4_CS_SP_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=LPO4;
      oparms.to_prec_gen=PArity;

#endif
   }
   else if(
      ( /* CLASS_G-SM-SSMM21-D Solved: 2 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-MMLM21-M Solved: 2 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___003_K18_F1_PI_AE_S4_CS_SP_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-SM-SSLM31-D Solved: 43 of 320 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_U-PS-FFSF21-M Solved: 43 of 53 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "U_____043_K19_F1_PI_AE_CS_SP_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvModFreqRankMax0;
      oparms.to_prec_gen=PByInvFreqHack;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_H-PM-FFSF22-M Solved: 12 of 15 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____042_B30_F1_PI_AE_SP_S2S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplexAHP;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=LPO4;
      oparms.to_prec_gen=PByInvFreqHack;

#endif
   }
   else if(
      ( /* CLASS_G-SM-SFMM31-D Solved: 82 of 118 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___003_K18_F1_PI_AE_S4_CS_OS_S0Y_backup";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodOrientedSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_H-SM-FFSF21-D Solved: 6 of 16 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMS21-M Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMS21-M Solved: 32 of 36 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SSMM31-M Solved: 7 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SFMM21-D Solved: 21 of 24 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SSMS31-D Solved: 3 of 12 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-SS-FFSS21-M Solved: 6 of 6 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-MMMM21-M Solved: 25 of 30 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___007_K18_F1_PI_AE_S4_CS_SP_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_H-NS-FFSF21-D Solved: 12 of 16 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-MMLM00-M Solved: 31 of 64 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____011_K07_F1_PI_AE_SP_SOV";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=PSelectComplexExceptRRHorn;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WConstantWeight;
      oparms.to_prec_gen=PByInvFrequency;

#endif
   }
   else if(
      ( /* CLASS_U-SM-SFMM22-M Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___010_K18_F2_PI_AE_S4_CS_SP_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=2;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-SM-SMMM21-D Solved: 6 of 14 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SMMM21-D Solved: 5 of 9 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SSMF31-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-MMMM21-D Solved: 10 of 17 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-MMLM21-M Solved: 4 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___003_K18_F1_PI_AE_S4_CS_SP_S2S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectNewComplexAHP;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-NF-SFMM00-M Solved: 7 of 17 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFSS21-D Solved: 2 of 5 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSM00-M Solved: 17 of 18 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFMS00-M Solved: 4 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____102_K18_F1_PI_AE_S4_CS_S1S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectComplexAHP;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_H-SF-FFSF33-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMF32-M Solved: 1 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-SFMF22-D Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMM22-M Solved: 6 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMM21-M Solved: 17 of 17 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFSS22-M Solved: 10 of 10 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PM-FFSF21-D Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-PM-FFSS21-M Solved: 5 of 5 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-MMLS31-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-MMLF21-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFMF32-D Solved: 2 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMM21-M Solved: 5 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-PF-FFSF21-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-SSMM33-M Solved: 14 of 14 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-SSMM22-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-MMLM31-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-MMMM31-M Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-PS-FFSF21-M Solved: 4 of 5 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFMM32-D Solved: 12 of 12 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSS21-M Solved: 5 of 5 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-MMLM22-M Solved: 16 of 25 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SSMF11-M Solved: 12 of 18 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-MMLM31-M Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSF22-M Solved: 10 of 12 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFMF21-D Solved: 5 of 9 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFMF21-M Solved: 2 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SSMS31-M Solved: 23 of 35 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFSF32-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMM33-M Solved: 2 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFMS22-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMF21-M Solved: 7 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SFMS21-M Solved: 6 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-SSMM22-D Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMF22-D Solved: 3 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSF11-D Solved: 2 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-PM-FFSM22-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SSMM21-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SSMS31-M Solved: 8 of 13 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFMM32-M Solved: 1 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFSF22-M Solved: 7 of 8 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___010_K18_F1_PI_AE_S4_CS_SP_S2S_backup";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectNewComplexAHP;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_H-SM-FFMM22-M Solved: 3 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___045_K18_F1_PI_AE_S4_CS_SP_S2S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectNewComplexAHP;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-NF-FSMF11-M Solved: 12 of 12 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____031_K09_F1_PI_AE_SP_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WAritySqWeight;
      oparms.to_prec_gen=PArity;

#endif
   }
   else if(
      ( /* CLASS_H-SM-FFSF22-M Solved: 33 of 35 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____042_B03_F1_PI_AE_SP_S2S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplexAHP;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=LPO4;
      oparms.to_prec_gen=PInvArity;

#endif
   }
   else if(
      ( /* CLASS_G-NF-MMMM00-M Solved: 16 of 34 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___011_K18_F1_PI_AE_S4_CS_SP_S0Y_backup";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-SM-SFMS21-D Solved: 18 of 29 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SFMM33-M Solved: 1 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___010_K18_F1_PI_AE_CS_SP_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-PF-MMLM21-M Solved: 21 of 26 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFMS21-M Solved: 11 of 11 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___044_K18_F1_PI_AE_S4_SP_S2S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplexAHP;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-NF-FFSS21-M Solved: 16 of 16 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-MMMM31-M Solved: 25 of 25 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SSMM33-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SSLS33-M Solved: 4 of 39 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SSMS11-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____031_K18_F1_PI_AE_CS_SP_S3T";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=PSelectNewComplexAHPExceptUniqMaxHorn;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-SF-SFMS31-M Solved: 6 of 16 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMS33-M Solved: 6 of 16 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___003_K18_F1_AE_S4_CS_SP_S0Y";
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-SM-SFMS33-M Solved: 5 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SSMS00-M Solved: 11 of 13 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___044_K18_F1_PI_AE_S4_S1S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectComplexAHP;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-SF-FFSS11-M Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSF11-D Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-MMMS00-M Solved: 0 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSS21-M Solved: 6 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SSMF32-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-SSMS22-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSS22-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMF31-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMF32-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SMMM31-M Solved: 9 of 9 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-SFMM00-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-SSMM32-M Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SSMS32-M Solved: 20 of 20 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-SFMF11-M Solved: 4 of 4 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-SFMS11-M Solved: 2 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFMF32-M Solved: 1 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSS00-M Solved: 35 of 42 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSM22-M Solved: 4 of 4 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-SSMS22-D Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-SSMM11-M Solved: 39 of 39 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSF31-M Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SSLF21-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SSLF33-M Solved: 2 of 12 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFMF11-M Solved: 2 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-SFMF22-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMS22-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-MMLM21-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFSM33-D Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-SSMF32-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSS31-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMS31-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFMM00-M Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMS32-M Solved: 3 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMF21-M Solved: 7 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SSLM33-M Solved: 0 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFSS11-M Solved: 5 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMS33-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMF22-M Solved: 10 of 10 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMS31-M Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-MMLM22-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFSF11-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-SSMS21-M Solved: 18 of 18 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSM00-M Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-MSMM22-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-SFMM21-D Solved: 34 of 34 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-SFMM21-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFMF11-D Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-SSMF00-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-MSLM22-M Solved: 2 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-SFMF22-D Solved: 6 of 6 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFSF11-M Solved: 3 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMS21-M Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSS22-M Solved: 2 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SFMM32-M Solved: 22 of 29 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-SFMF22-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSS21-M Solved: 2 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFSF32-M Solved: 4 of 7 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SFMF11-M Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-SFMM00-M Solved: 16 of 16 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-PM-FFSS22-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PS-FFSF11-M Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-MMLS32-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-NS-FFSF11-M Solved: 3 of 3 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SFMM00-M Solved: 9 of 9 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSF32-M Solved: 8 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PF-FFSF22-M Solved: 11 of 68 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSS22-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SSMM33-M Solved: 23 of 23 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSM22-M Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SFMM33-M Solved: 3 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSS00-M Solved: 8 of 8 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-MSMM21-M Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SFMM31-M Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FFSF11-M Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSF31-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PM-FFMF21-D Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFMM21-D Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_U-PF-FFSF21-M Solved: 27 of 28 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FFSF00-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-MMLM00-M Solved: 200 of 200 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFSF33-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFSF11-M Solved: 1 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-NF-FFSF00-M Solved: 16 of 16 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSF21-M Solved: 3 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMS22-M Solved: 8 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-MMLM31-D Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFMF21-D Solved: 1 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-SFMS00-M Solved: 2 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMM22-M Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-PS-FFSS22-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFMM32-D Solved: 1 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSF00-M Solved: 28 of 28 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMF31-D Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSM21-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFSM21-M Solved: 1 of 17 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSF00-M Solved: 6 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSF11-D Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSF11-M Solved: 61 of 63 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSF33-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-SSMF32-M Solved: 16 of 56 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMF21-D Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFSS21-M Solved: 2 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMS00-M Solved: 8 of 17 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-SSMM31-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-SFMS00-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SFSM00-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFMM21-M Solved: 30 of 30 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-PS-FFSF21-D Solved: 1 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-PS-FFSF22-D Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-SFMM11-M Solved: 4 of 4 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SFMM11-M Solved: 9 of 12 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SSMM11-M Solved: 10 of 10 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFSF22-M Solved: 18 of 19 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFSF22-M Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SSMM32-M Solved: 0 of 20 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFMS11-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-SSMS32-M Solved: 2 of 19 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-SSMM31-D Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SSMS32-M Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-NM-FFSF22-M Solved: 2 of 2 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SSMM32-M Solved: 91 of 101 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSF00-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SFMM32-M Solved: 6 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SFMS00-M Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMM32-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFSF21-D Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFMF32-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-MMLM22-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PF-FFSM22-M Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SS-FFSF21-M Solved: 15 of 19 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSS11-M Solved: 6 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMS31-D Solved: 2 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-SS-FFSF22-M Solved: 9 of 11 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMS21-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-SFMF00-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PS-FFSF21-D Solved: 19 of 31 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-SSMS31-D Solved: 2 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSF31-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFSF21-M Solved: 19 of 20 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-SSMM00-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-NF-FFSM32-D Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFSF21-M Solved: 3 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-MMLM22-D Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SSMF21-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-MSMS32-M Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PF-FFSM21-M Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-SFMM21-D Solved: 4 of 4 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-SSMF22-D Solved: 3 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-PF-FFSF22-M Solved: 0 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-NS-FFSF22-M Solved: 4 of 4 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PF-FFSS22-M Solved: 2 of 2 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-MMLM21-D Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMM31-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-SM-SFMM21-M Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMF21-M Solved: 4 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-SFMM21-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFSS00-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SFMF21-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-MMLS31-D Solved: 2 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFMF21-M Solved: 5 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SSMM11-D Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFMM21-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFMF21-D Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFSS21-M Solved: 8 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMF22-M Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-MSMM32-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMM32-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PF-FFSF00-M Solved: 19 of 19 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMF00-M Solved: 5 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-PM-FFMM21-D Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_U-PS-FFSS21-D Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SSMS33-M Solved: 3 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSM11-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSS32-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-SFMM21-M Solved: 23 of 23 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMF33-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSF33-M Solved: 1 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-SFMM31-M Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-SFMM22-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFSS11-M Solved: 2 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMS11-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-SFMM31-D Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSF22-D Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFSS11-D Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NS-FFMS21-M Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSF22-M Solved: 12 of 12 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFSF11-M Solved: 5 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-SSMM00-M Solved: 2 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-MMLS00-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFSS21-M Solved: 2 of 2 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMF32-M Solved: 5 of 5 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSS32-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSF22-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFSF21-M Solved: 15 of 15 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-NF-FFSF11-M Solved: 10 of 10 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFSF21-M Solved: 3 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SMLM33-M Solved: 20 of 20 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFSF21-D Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-MMLM00-M Solved: 9 of 9 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMS32-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSS32-D Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFSF22-M Solved: 1 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSM00-M Solved: 3 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFSS22-M Solved: 1 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SSMF32-M Solved: 0 of 16 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMM21-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSM22-M Solved: 12 of 12 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMF11-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-FFMF22-D Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SSMM22-M Solved: 6 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-MMLM11-M Solved: 0 of 11 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SFMF00-M Solved: 12 of 13 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-NF-FFSF22-M Solved: 2 of 2 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-SFMF11-M Solved: 4 of 4 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSF00-M Solved: 71 of 72 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-NF-FFSF21-M Solved: 3 of 3 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SFSS00-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFMS21-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFMF21-D Solved: 1 of 5 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFMF22-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SFMF21-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PM-FFSS22-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMS32-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SMLF00-M Solved: 36 of 36 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SSMF33-M Solved: 12 of 12 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFMF22-D Solved: 1 of 2 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSF21-M Solved: 19 of 19 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFMF21-D Solved: 14 of 29 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSF21-D Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFMF21-M Solved: 15 of 20 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-SFMS11-M Solved: 2 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMF32-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-SSMM22-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFMM31-M Solved: 0 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-SFMM22-M Solved: 22 of 22 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMM33-M Solved: 1 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SMMF11-M Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-FFMS32-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFMM22-M Solved: 6 of 6 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-MMLM21-D Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSF22-M Solved: 41 of 41 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMF31-M Solved: 6 of 13 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PF-FFMF11-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SM-FFMS22-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-SFMS22-M Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFMF32-M Solved: 0 of 1 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMM31-M Solved: 2 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PF-FFSF11-M Solved: 2 of 2 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMF33-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFSM11-M Solved: 2 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SFMS11-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SSMM32-M Solved: 0 of 2 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NF-FFSF11-M Solved: 15 of 15 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-FFMM32-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-SFMF33-M Solved: 3 of 3 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SSMM31-M Solved: 1 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMM31-M Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SF-SFMM11-M Solved: 6 of 6 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity1(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFSF21-D Solved: 8 of 23 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-SFMS22-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NM-SFMS22-D Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SFMM22-M Solved: 4 of 4 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-SFMM21-M Solved: 4 of 12 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-SFMM31-D Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-FFMM33-M Solved: 0 of 3 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-MMLF33-M Solved: 0 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PS-FFMM21-M Solved: 129 of 129 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NS-FFMM21-D Solved: 2 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecDeepMaxDepth(spec))
       ||
      ( /* CLASS_U-NF-FFSM00-M Solved: 2 of 2 */
       SpecAxiomsAreUnit(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity0(spec)&&
       SpecAvgFArity0(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SS-SSMF21-M Solved: 7 of 8 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SM-SFMF33-M Solved: 17 of 19 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-FFMF33-M Solved: 1 of 1 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity3Plus(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_H-SM-FFSF22-D Solved: 1 of 1 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecDeepMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____036_K18_F2_PI_AE_S4_SP_S2S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.selection_strategy=SelectNewComplexAHP;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-SF-SSMF31-M Solved: 3 of 9 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecSomeLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PM-FFSF21-M Solved: 4 of 7 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-SF-SFMF32-M Solved: 14 of 28 */
       SpecAxiomsAreGeneral(spec)&&
       SpecSomeEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PF-FFSF32-M Solved: 5 of 6 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_U-PM-FFMS21-M Solved: 6 of 8 */
       SpecAxiomsAreUnit(spec)&&
       SpecPureEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-FFMM32-M Solved: 3 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "G_E___006_K18_F1_PI_AE_S4_CS_SP_S0Y";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else if(
      ( /* CLASS_G-NF-SFMS32-M Solved: 1 of 6 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____102_B03_F1_PI_AE_S4_CS_SP_S2S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectNewComplexAHP;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=LPO4;
      oparms.to_prec_gen=PInvArity;

#endif
   }
   else if(
      ( /* CLASS_G-NF-FFMM21-M Solved: 59 of 155 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-NF-MMLM32-M Solved: 17 of 17 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecManyAxioms(spec)&&
       SpecManyLiterals(spec)&&
       SpecLargeTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity3Plus(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____102_B31_F1_PI_AE_S4_CS_SP_S2S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectNewComplexAHP;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.ordertype=LPO4;
      oparms.to_prec_gen=PByInvFreqConstMin;

#endif
   }
   else if(
      ( /* CLASS_G-NF-FFMS21-M Solved: 60 of 116 */
       SpecAxiomsAreGeneral(spec)&&
       SpecNoEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-PF-FFSS22-M Solved: 1 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecPureEq(spec)&&
       SpecFewNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecSomeGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_G-PS-SFMM21-M Solved: 55 of 55 */
       SpecAxiomsAreGeneral(spec)&&
       SpecPureEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecSomeAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-NM-FFMF21-M Solved: 8 of 10 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecNoEq(spec)&&
       SpecManyNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecMediumTerms(spec)&&
       SpecFewGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity1(spec)&&
       SpecMediumMaxDepth(spec))
       ||
      ( /* CLASS_H-SS-FFSM22-M Solved: 2 of 2 */
       SpecAxiomsAreNonUnitHorn(spec)&&
       SpecSomeEq(spec)&&
       SpecSomeNGPosUnits(spec)&&
       SpecFewAxioms(spec)&&
       SpecFewLiterals(spec)&&
       SpecSmallTerms(spec)&&
       SpecManyGroundPos(spec)&&
       SpecMaxFArity2(spec)&&
       SpecAvgFArity2(spec)&&
       SpecMediumMaxDepth(spec)))
   {
#ifdef CHE_HEURISTICS_INTERNAL
      res = "H_____102_K18_F1_PI_AE_S4_CS_SP_S2S";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectNewComplexAHP;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
   else /* Default */
   {
#ifdef CHE_HEURISTICS_INTERNAL
  res = "G_E___010_K18_F1_PI_AE_S4_CS_SP_S0Y_backup";
      control->heuristic_parms.prefer_initial_clauses=true;
      control->heuristic_parms.forward_context_sr = true;
      control->heuristic_parms.selection_strategy=SelectMaxLComplexAvoidPosPred;
      control->heuristic_parms.split_clauses=4;
      control->heuristic_parms.split_aggressive=true;
      control->heuristic_parms.er_varlit_destructive=true;
      control->heuristic_parms.er_aggressive=true;
      control->heuristic_parms.forward_demod=1;
      control->heuristic_parms.pm_type=ParamodAlwaysSim;

#endif
#ifdef TO_ORDERING_INTERNAL
      oparms.to_weight_gen=WInvFrequencyRank;
      oparms.to_prec_gen=PByInvFrequency;
      oparms.to_const_weight=1;

#endif
   }
#endif

/* Total solutions on test set: 5037 */
/* -------------------------------------------------------*/
/*     End of automatically generated code.               */
/* -------------------------------------------------------*/

